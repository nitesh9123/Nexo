/**
 * Electron Preload Script - Provider App
 * Exposes secure API to the renderer process
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  // Authentication
  login: (credentials) => ipcRenderer.invoke('provider-login', credentials),
  getProfile: (userId) => ipcRenderer.invoke('get-profile', userId),
  
  // Service Requests
  getNewRequests: (filters) => ipcRenderer.invoke('get-new-requests', filters),
  acceptRequest: (bookingId, providerId) => ipcRenderer.invoke('accept-request', { bookingId, providerId }),
  
  // Jobs Management
  getProviderJobs: (providerId, status) => ipcRenderer.invoke('get-provider-jobs', { providerId, status }),
  updateJobStatus: (data) => ipcRenderer.invoke('update-job-status', data),
  
  // Earnings
  getProviderEarnings: (providerId) => ipcRenderer.invoke('get-provider-earnings', { providerId }),
  
  // Services
  getServiceCategories: () => ipcRenderer.invoke('get-service-categories'),
  
  // Platform info
  platform: process.platform,
  
  // Window controls
  minimizeWindow: () => ipcRenderer.send('minimize-window'),
  maximizeWindow: () => ipcRenderer.send('maximize-window'),
  closeWindow: () => ipcRenderer.send('close-window'),
});
