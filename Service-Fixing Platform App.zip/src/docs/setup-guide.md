# Complete Setup Guide - Service Fixing Platform

This guide will walk you through setting up the entire Service Fixing Platform from scratch.

## Table of Contents
1. [System Requirements](#system-requirements)
2. [Software Installation](#software-installation)
3. [Database Setup](#database-setup)
4. [Python Environment Setup](#python-environment-setup)
5. [Customer App Setup](#customer-app-setup)
6. [Provider App Setup](#provider-app-setup)
7. [Running the Applications](#running-the-applications)
8. [Troubleshooting](#troubleshooting)

---

## System Requirements

### Minimum Requirements
- **OS**: Windows 10/11, macOS 10.14+, Ubuntu 20.04+
- **RAM**: 4 GB
- **Storage**: 2 GB free space
- **Processor**: Intel Core i3 or equivalent

### Recommended Requirements
- **RAM**: 8 GB or more
- **Storage**: 5 GB free space
- **Processor**: Intel Core i5 or equivalent

---

## Software Installation

### 1. Node.js Installation

**Windows:**
1. Download Node.js 18+ from https://nodejs.org/
2. Run the installer
3. Follow installation wizard
4. Verify installation:
```bash
node --version
npm --version
```

**Expected Output:**
```
v18.x.x
9.x.x
```

### 2. Python Installation

**Windows:**
1. Download Python 3.8+ from https://python.org/downloads/
2. Run installer
3. ✅ **IMPORTANT**: Check "Add Python to PATH"
4. Click "Install Now"
5. Verify installation:
```bash
python --version
pip --version
```

**Expected Output:**
```
Python 3.x.x
pip 23.x.x
```

### 3. MySQL Installation

**Windows:**
1. Download MySQL Installer from https://dev.mysql.com/downloads/installer/
2. Choose "MySQL Installer Community"
3. Run installer
4. Select "Developer Default" setup type
5. Set root password (remember this!)
6. Complete installation
7. Verify installation:
```bash
mysql --version
```

**Expected Output:**
```
mysql  Ver 8.0.x for Win64
```

---

## Database Setup

### Step 1: Create Database

1. Open Command Prompt as Administrator
2. Login to MySQL:
```bash
mysql -u root -p
```
3. Enter your root password
4. Create database:
```sql
CREATE DATABASE service_platform CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```
5. Verify:
```sql
SHOW DATABASES;
```
6. Exit MySQL:
```sql
EXIT;
```

### Step 2: Import Schema

Navigate to project directory:
```bash
cd path/to/service-fixing-platform
mysql -u root -p service_platform < database/schema.sql
```

**Expected Output:**
```
(No errors = success)
```

### Step 3: Import Seed Data

```bash
mysql -u root -p service_platform < database/seed_data.sql
```

### Step 4: Verify Database

```bash
mysql -u root -p service_platform
```

```sql
-- Check tables
SHOW TABLES;

-- Expected: 5 tables
-- users
-- services
-- bookings
-- booking_status_history
-- provider_earnings

-- Check sample data
SELECT COUNT(*) FROM users;      -- Should show 10
SELECT COUNT(*) FROM services;   -- Should show 15
SELECT COUNT(*) FROM bookings;   -- Should show 13

EXIT;
```

### Step 5: Configure Database Connection

Edit `shared/backend/config.py`:

```python
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',          # Your MySQL username
    'password': 'your_password',  # Your MySQL password
    'database': 'service_platform',
    'port': 3306,
    'charset': 'utf8mb4'
}
```

---

## Python Environment Setup

### Step 1: Install Required Packages

Open Command Prompt in project directory:

```bash
# Install mysql-connector-python
pip install mysql-connector-python

# Install bcrypt for password hashing
pip install bcrypt
```

### Step 2: Verify Installation

```bash
pip list
```

**Should see:**
```
bcrypt                    x.x.x
mysql-connector-python    x.x.x
```

### Step 3: Test Database Connection

```bash
cd shared/backend/database
python connection.py
```

**Expected Output:**
```
Connection test: Connected to MySQL Server version 8.0.x
```

**If you see an error:**
- Check MySQL is running
- Verify credentials in config.py
- Check firewall settings

---

## Customer App Setup

### Step 1: Navigate to Customer App

```bash
cd customer-app
```

### Step 2: Install Dependencies

```bash
npm install
```

**This will take 2-5 minutes**

Expected packages installed:
- react, react-dom, react-router-dom
- electron, electron-builder
- lucide-react
- And ~500 other dependencies

### Step 3: Verify Installation

Check for errors in output. If none, installation is successful.

```bash
# Check if node_modules folder exists
dir node_modules  # Windows
ls node_modules   # Mac/Linux
```

---

## Provider App Setup

### Step 1: Navigate to Provider App

```bash
cd ../provider-app
```

### Step 2: Install Dependencies

```bash
npm install
```

**This will take 2-5 minutes**

---

## Running the Applications

### Option 1: Development Mode (Recommended for Testing)

**Customer App:**
```bash
cd customer-app
npm run electron-dev
```

**What happens:**
1. React dev server starts on port 3000
2. Electron app opens automatically
3. Hot reload enabled (changes reflect immediately)

**Provider App:**
Open a NEW Command Prompt window:
```bash
cd provider-app
npm run electron-dev
```

**What happens:**
1. React dev server starts on port 3001
2. Electron app opens automatically

### Option 2: Production Build

**Customer App:**
```bash
cd customer-app
npm run build
npm run electron
```

**Provider App:**
```bash
cd provider-app
npm run build
npm run electron
```

### Option 3: Create Installer (Windows)

**Customer App:**
```bash
cd customer-app
npm run electron-build
```

**Output:**
- `dist/Service Fixing - Customer Setup x.x.x.exe`

**Provider App:**
```bash
cd provider-app
npm run electron-build
```

**Output:**
- `dist/Service Fixing - Provider Setup x.x.x.exe`

---

## Testing the Applications

### Test Customer App

1. **Open Customer App**
2. **Login Screen:**
   - Email: `john.smith@email.com`
   - Password: `password123`
   - Click "Login"

3. **Expected:** Dashboard with services

4. **Test Booking:**
   - Click "Services"
   - Choose any service
   - Click "Book Now"
   - Fill form
   - Submit

5. **Verify in Database:**
```sql
SELECT * FROM bookings ORDER BY created_at DESC LIMIT 1;
```

### Test Provider App

1. **Open Provider App**
2. **Login Screen:**
   - Email: `robert.electrician@provider.com`
   - Password: `password123`
   - Click "Login"

3. **Expected:** Provider dashboard

4. **Test Accept Request:**
   - Click "New Requests"
   - Click "Accept" on any request
   - Verify status changes

5. **Verify in Database:**
```sql
SELECT * FROM bookings WHERE provider_id IS NOT NULL ORDER BY updated_at DESC LIMIT 1;
```

---

## Troubleshooting

### Issue 1: Python Not Found

**Error:**
```
'python' is not recognized as an internal or external command
```

**Solution:**
1. Add Python to PATH
2. OR modify `electron/main.js`:
```javascript
const pythonPath = 'C:\\Python39\\python.exe'; // Your Python path
```

### Issue 2: MySQL Connection Error

**Error:**
```
Database connection error: Access denied for user
```

**Solutions:**
1. Check MySQL is running:
```bash
# Windows
services.msc
# Look for MySQL80 service

# Start if stopped
net start MySQL80
```

2. Verify credentials in `config.py`

3. Reset MySQL password if forgotten

### Issue 3: Port Already in Use

**Error:**
```
Port 3000 is already in use
```

**Solution:**
```bash
# Windows - Kill process on port 3000
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# Or change port in package.json
```

### Issue 4: npm install Fails

**Error:**
```
npm ERR! code EACCES
```

**Solution:**
```bash
# Clear npm cache
npm cache clean --force

# Try again
npm install
```

### Issue 5: Electron App Won't Start

**Error:**
```
Electron failed to start
```

**Solutions:**
1. Check Node.js version (must be 18+)
2. Delete `node_modules` and reinstall:
```bash
rm -rf node_modules package-lock.json
npm install
```

### Issue 6: React App Blank Screen

**Solutions:**
1. Open DevTools (Ctrl+Shift+I)
2. Check Console for errors
3. Verify `build` folder exists
4. Check `electron/main.js` startUrl

### Issue 7: Python Script Errors

**Error:**
```
ModuleNotFoundError: No module named 'mysql'
```

**Solution:**
```bash
pip install mysql-connector-python bcrypt
```

### Issue 8: Database Query Errors

**Error:**
```
Table 'service_platform.users' doesn't exist
```

**Solution:**
```bash
# Re-import schema
mysql -u root -p service_platform < database/schema.sql
```

---

## Verification Checklist

Before demonstration, verify:

- [ ] MySQL service is running
- [ ] Database has sample data
- [ ] Python dependencies installed
- [ ] Customer app opens successfully
- [ ] Provider app opens successfully
- [ ] Login works for both apps
- [ ] Can create a booking
- [ ] Can accept a request
- [ ] Status updates work
- [ ] Payment simulation works

---

## Development Tips

### 1. Running Both Apps Simultaneously

Use two terminal windows:
```bash
# Terminal 1 - Customer App
cd customer-app && npm run electron-dev

# Terminal 2 - Provider App
cd provider-app && npm run electron-dev
```

### 2. Viewing Python Logs

Check Electron DevTools Console for Python stdout/stderr

### 3. Database Changes

After modifying database:
```bash
# Restart Python (by restarting Electron app)
# OR
# Re-run the database operation
```

### 4. Code Changes

**React Code:**
- Saves automatically reload (hot reload)

**Python Code:**
- Restart Electron app to see changes

**Electron Code:**
- Restart Electron app to see changes

---

## Quick Start Commands

```bash
# Database
mysql -u root -p
CREATE DATABASE service_platform;
EXIT;
mysql -u root -p service_platform < database/schema.sql
mysql -u root -p service_platform < database/seed_data.sql

# Python
pip install mysql-connector-python bcrypt

# Customer App
cd customer-app
npm install
npm run electron-dev

# Provider App (new terminal)
cd provider-app
npm install
npm run electron-dev
```

---

## Getting Help

If you encounter issues:

1. **Check Error Messages** - Read carefully
2. **Google the Error** - Often has solutions
3. **Check Documentation** - README files
4. **Verify Prerequisites** - All software installed
5. **Ask for Help** - Provide error details

---

## Next Steps

After successful setup:
1. Review [README.md](./README.md)
2. Study [Presentation Outline](./presentation-outline.md)
3. Practice the demo flow
4. Prepare for viva questions

---

**Setup Complete! 🎉**

You're now ready to demonstrate the Service Fixing Platform!
