# Service Fixing Platform - Desktop Application

A comprehensive desktop application system for connecting customers with service providers for home repair and maintenance services.

## 📋 Project Overview

The Service Fixing Platform consists of two separate desktop applications:

1. **Customer App** - For customers to browse, book, and track service requests
2. **Provider App** - For service providers to manage jobs, update status, and track earnings

## 🏗️ Architecture

```
React (UI) → Electron (Desktop) → Python (Backend) → MySQL (Database)
```

### Technology Stack

- **Frontend**: React 18, React Router, Lucide Icons
- **Desktop**: Electron 27
- **Backend**: Python 3.x
- **Database**: MySQL 8.0
- **Communication**: Electron IPC + Child Process

## 🚀 Features

### Customer App

- ✅ User Registration & Login
- ✅ Browse Services by Category
- ✅ Book Services with Preferred Date/Time
- ✅ Track Booking Status in Real-time
- ✅ View Booking History
- ✅ Cancel Bookings
- ✅ Simulated Payment Processing

### Provider App

- ✅ Provider Login
- ✅ View New Service Requests
- ✅ Accept/Reject Requests
- ✅ Manage Active Jobs
- ✅ Update Job Status (Accepted → In Progress → Completed)
- ✅ View Earnings Summary
- ✅ Detailed Earnings History

## 📦 Installation

### Prerequisites

- Node.js 18 or higher
- Python 3.8 or higher
- MySQL 8.0 or higher
- npm or yarn

### Database Setup

1. Create MySQL database:
```bash
mysql -u root -p
CREATE DATABASE service_platform;
```

2. Import schema and seed data:
```bash
mysql -u root -p service_platform < database/schema.sql
mysql -u root -p service_platform < database/seed_data.sql
```

3. Update database configuration:
Edit `shared/backend/config.py` with your MySQL credentials:
```python
DB_CONFIG = {
    'host': 'localhost',
    'user': 'your_username',
    'password': 'your_password',
    'database': 'service_platform',
    'port': 3306
}
```

### Python Dependencies

```bash
pip install mysql-connector-python bcrypt
```

### Customer App Setup

```bash
cd customer-app
npm install
```

**Development Mode:**
```bash
npm run electron-dev
```

**Build for Production:**
```bash
npm run electron-build
```

### Provider App Setup

```bash
cd provider-app
npm install
```

**Development Mode:**
```bash
npm run electron-dev
```

**Build for Production:**
```bash
npm run electron-build
```

## 🎯 Usage

### Demo Credentials

**Customer Account:**
- Email: `john.smith@email.com`
- Password: `password123`

**Provider Account:**
- Email: `robert.electrician@provider.com`
- Password: `password123`

### Workflow

1. **Customer** logs in and browses available services
2. **Customer** books a service with preferred date/time
3. Booking status: **Requested** (waiting for provider)
4. **Provider** logs in and views new requests
5. **Provider** accepts the request
6. Booking status: **Accepted** (scheduled)
7. **Provider** starts work
8. Booking status: **In Progress**
9. **Provider** completes the job
10. Booking status: **Completed**
11. **Customer** makes payment (simulated)
12. **Provider** receives earnings

## 📁 Project Structure

```
service-fixing-platform/
│
├── customer-app/                 # Customer Desktop App
│   ├── electron/                 # Electron configuration
│   │   ├── main.js              # Main process
│   │   └── preload.js           # Preload script
│   ├── src/                     # React source
│   │   ├── components/          # React components
│   │   ├── pages/               # Page components
│   │   ├── context/             # Context providers
│   │   ├── utils/               # Utility functions
│   │   ├── App.jsx              # Main app component
│   │   └── index.jsx            # Entry point
│   └── package.json
│
├── provider-app/                # Provider Desktop App
│   ├── electron/
│   ├── src/
│   └── package.json
│
├── shared/                      # Shared Backend
│   └── backend/
│       ├── handlers/            # Python request handlers
│       │   ├── auth_handler.py
│       │   ├── service_handler.py
│       │   ├── booking_handler.py
│       │   ├── provider_handler.py
│       │   └── payment_handler.py
│       ├── database/
│       │   └── connection.py
│       ├── utils/
│       │   ├── validator.py
│       │   ├── hasher.py
│       │   └── response.py
│       └── config.py
│
├── database/                    # Database Scripts
│   ├── schema.sql              # Database schema
│   └── seed_data.sql           # Sample data
│
└── docs/                       # Documentation
    ├── README.md
    ├── presentation-outline.md
    └── architecture.md
```

## 🔒 Security Features

1. **Password Hashing** - bcrypt with 12 rounds
2. **Context Isolation** - Electron security best practice
3. **Input Validation** - Frontend and backend validation
4. **SQL Injection Prevention** - Parameterized queries
5. **XSS Protection** - React's built-in escaping

## 🗃️ Database Schema

### Tables

1. **users** - Customer and provider accounts
2. **services** - Available services catalog
3. **bookings** - Service booking records
4. **booking_status_history** - Status change audit trail
5. **provider_earnings** - Provider payment tracking

### Key Relationships

- `users(1) → bookings(many)` - One user can have many bookings
- `services(1) → bookings(many)` - One service can be booked many times
- `bookings(1) → booking_status_history(many)` - Booking status changes
- `provider_earnings(many) → provider(1)` - Provider earnings records

## 🔄 Data Flow

### Example: Creating a Booking

1. **React Component**
   ```javascript
   const data = await window.api.createBooking(bookingData);
   ```

2. **Electron Preload**
   ```javascript
   ipcRenderer.invoke('create-booking', bookingData)
   ```

3. **Electron Main**
   ```javascript
   spawn('python', ['booking_handler.py', 'create', JSON.stringify(data)])
   ```

4. **Python Handler**
   ```python
   result = create_booking(data)
   print(json.dumps(result))
   ```

5. **MySQL Database**
   ```sql
   INSERT INTO bookings (...) VALUES (...)
   ```

## 🧪 Testing

### Python Backend Testing
```bash
cd shared/backend
python -m pytest tests/
```

### React Component Testing
```bash
cd customer-app
npm test
```

### Manual Testing
1. Test all user workflows
2. Test error scenarios
3. Test edge cases
4. Cross-check database updates

## 📊 Project Metrics

- **Lines of Code**: ~3000+
- **React Components**: 20+
- **Python Handlers**: 5
- **Database Tables**: 5
- **API Endpoints**: 15+
- **Development Time**: 8 weeks

## 🚧 Known Limitations

1. **No Real-time Updates** - Manual refresh needed
2. **Simulated Payment** - No actual payment gateway
3. **Single Provider Assignment** - One provider per booking
4. **Local Database** - No cloud sync
5. **Desktop Only** - No mobile version

## 🔮 Future Enhancements

### Phase 1
- [ ] Real-time notifications using WebSocket
- [ ] Push notifications
- [ ] In-app messaging

### Phase 2
- [ ] Provider ratings and reviews
- [ ] Service history analytics
- [ ] Advanced search and filters

### Phase 3
- [ ] Real payment gateway integration
- [ ] Invoice generation
- [ ] Tax calculations

### Phase 4
- [ ] Mobile apps (React Native)
- [ ] Admin dashboard
- [ ] Multi-language support

## 🤝 Contributing

This is a college project. For educational purposes only.

## 📝 License

MIT License - See LICENSE file for details

## 👥 Authors

- Student Name - [Your Email]
- Guide: Professor Name
- Institution: College Name

## 📞 Support

For issues and queries:
- Email: your.email@example.com
- GitHub: [Your GitHub Profile]

## 🙏 Acknowledgments

- College/University Name
- Project Guide
- Department of Computer Science
- Open source community

---

**Note**: This project is developed for educational purposes as part of a college curriculum.

## 📚 Additional Resources

- [Architecture Documentation](./architecture.md)
- [Presentation Outline](./presentation-outline.md)
- [API Documentation](./api-documentation.md)
- [Database Design](./database-design.md)

---

**Last Updated**: February 2026
**Version**: 1.0.0
**Status**: ✅ Complete and Ready for Demonstration
