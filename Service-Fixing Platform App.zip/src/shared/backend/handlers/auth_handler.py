"""
Authentication Handler
Handles user registration and login
"""

import sys
import os
import json

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.connection import get_db_connection
from utils.validator import validate_user_data, validate_email, sanitize_string
from utils.hasher import hash_password, verify_password
from utils.response import success_response, error_response, format_user_data, to_json
from config import ERROR_MESSAGES, SUCCESS_MESSAGES, USER_TYPES

def register_user(data):
    """
    Register a new user
    
    Args:
        data (dict): User registration data
            - fullName: User's full name
            - email: User's email
            - phone: User's phone (optional)
            - password: User's password
            - userType: 'customer' or 'provider'
            - address: User's address (optional)
            - city: User's city (optional)
            - state: User's state (optional)
    
    Returns:
        dict: Success or error response
    """
    try:
        # Validate input data
        is_valid, error_msg = validate_user_data(data, is_registration=True)
        if not is_valid:
            return error_response(error_msg, 'VALIDATION_ERROR')
        
        # Get database connection
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Check if user already exists
        cursor.execute("SELECT user_id FROM users WHERE email = %s", (data['email'],))
        existing_user = cursor.fetchone()
        
        if existing_user:
            cursor.close()
            conn.close()
            return error_response(ERROR_MESSAGES['user_exists'], 'USER_EXISTS')
        
        # Hash password
        password_hash = hash_password(data['password'])
        
        # Prepare user data
        full_name = sanitize_string(data['fullName'], 100)
        email = sanitize_string(data['email'], 100).lower()
        phone = sanitize_string(data.get('phone', ''), 15)
        user_type = data.get('userType', USER_TYPES['CUSTOMER'])
        address = sanitize_string(data.get('address', ''))
        city = sanitize_string(data.get('city', ''), 50)
        state = sanitize_string(data.get('state', ''), 50)
        
        # Insert new user
        query = """
            INSERT INTO users 
            (full_name, email, phone, password_hash, user_type, address, city, state)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """
        
        cursor.execute(query, (full_name, email, phone, password_hash, user_type, address, city, state))
        user_id = cursor.lastrowid
        conn.commit()
        
        # Get the created user
        cursor.execute("SELECT * FROM users WHERE user_id = %s", (user_id,))
        user = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        return success_response(
            data={
                'user': format_user_data(user)
            },
            message=SUCCESS_MESSAGES['registration_success']
        )
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

def login_user(data):
    """
    Authenticate a user
    
    Args:
        data (dict): Login credentials
            - email: User's email
            - password: User's password
            - userType: 'customer' or 'provider' (optional filter)
    
    Returns:
        dict: Success or error response with user data
    """
    try:
        # Validate input data
        is_valid, error_msg = validate_user_data(data, is_registration=False)
        if not is_valid:
            return error_response(error_msg, 'VALIDATION_ERROR')
        
        # Get database connection
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Find user by email
        email = sanitize_string(data['email'], 100).lower()
        cursor.execute("SELECT * FROM users WHERE email = %s", (email,))
        user = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        # Check if user exists
        if not user:
            return error_response(ERROR_MESSAGES['invalid_credentials'], 'INVALID_CREDENTIALS')
        
        # Check if user is active
        if not user.get('is_active', True):
            return error_response('Account is deactivated', 'ACCOUNT_INACTIVE')
        
        # Verify password
        if not verify_password(data['password'], user['password_hash']):
            return error_response(ERROR_MESSAGES['invalid_credentials'], 'INVALID_CREDENTIALS')
        
        # Check user type if specified
        if 'userType' in data and data['userType']:
            if user['user_type'] != data['userType']:
                return error_response(f"Invalid user type. Expected {data['userType']}", 'INVALID_USER_TYPE')
        
        return success_response(
            data={
                'user': format_user_data(user)
            },
            message=SUCCESS_MESSAGES['login_success']
        )
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

def get_user_profile(data):
    """
    Get user profile by ID
    
    Args:
        data (dict): Request data
            - userId: User ID
    
    Returns:
        dict: Success or error response with user data
    """
    try:
        user_id = data.get('userId')
        if not user_id:
            return error_response('User ID is required', 'VALIDATION_ERROR')
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM users WHERE user_id = %s", (user_id,))
        user = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if not user:
            return error_response(ERROR_MESSAGES['user_not_found'], 'USER_NOT_FOUND')
        
        return success_response(data={'user': format_user_data(user)})
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

# Main execution
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(to_json(error_response("Invalid arguments", 'INVALID_ARGS')))
        sys.exit(1)
    
    action = sys.argv[1]
    data = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
    
    result = None
    
    if action == 'register':
        result = register_user(data)
    elif action == 'login':
        result = login_user(data)
    elif action == 'profile':
        result = get_user_profile(data)
    else:
        result = error_response(f"Unknown action: {action}", 'UNKNOWN_ACTION')
    
    print(to_json(result))
