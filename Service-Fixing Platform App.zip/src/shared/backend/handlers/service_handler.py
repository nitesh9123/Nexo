"""
Service Handler
Handles service-related operations
"""

import sys
import os
import json

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.connection import get_db_connection
from utils.response import success_response, error_response, format_service_data, to_json
from config import ERROR_MESSAGES

def get_all_services(data=None):
    """
    Get all active services
    
    Args:
        data (dict): Optional filters
            - category: Filter by category
            - searchTerm: Search in service name or description
    
    Returns:
        dict: Success or error response with services list
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Base query
        query = "SELECT * FROM services WHERE is_active = TRUE"
        params = []
        
        # Apply filters if provided
        if data:
            if 'category' in data and data['category']:
                query += " AND category = %s"
                params.append(data['category'])
            
            if 'searchTerm' in data and data['searchTerm']:
                search_term = f"%{data['searchTerm']}%"
                query += " AND (service_name LIKE %s OR description LIKE %s)"
                params.extend([search_term, search_term])
        
        query += " ORDER BY category, service_name"
        
        cursor.execute(query, params if params else None)
        services = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        # Format services
        formatted_services = [format_service_data(service) for service in services]
        
        return success_response(data={'services': formatted_services})
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

def get_service_by_id(data):
    """
    Get a specific service by ID
    
    Args:
        data (dict): Request data
            - serviceId: Service ID
    
    Returns:
        dict: Success or error response with service data
    """
    try:
        service_id = data.get('serviceId')
        if not service_id:
            return error_response('Service ID is required', 'VALIDATION_ERROR')
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute("SELECT * FROM services WHERE service_id = %s", (service_id,))
        service = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if not service:
            return error_response(ERROR_MESSAGES['service_not_found'], 'SERVICE_NOT_FOUND')
        
        return success_response(data={'service': format_service_data(service)})
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

def get_service_categories(data=None):
    """
    Get all unique service categories
    
    Returns:
        dict: Success or error response with categories list
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        query = """
            SELECT DISTINCT category, COUNT(*) as service_count
            FROM services 
            WHERE is_active = TRUE
            GROUP BY category
            ORDER BY category
        """
        
        cursor.execute(query)
        categories = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        return success_response(data={'categories': categories})
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

# Main execution
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(to_json(error_response("Invalid arguments", 'INVALID_ARGS')))
        sys.exit(1)
    
    action = sys.argv[1]
    data = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
    
    result = None
    
    if action == 'get_all':
        result = get_all_services(data)
    elif action == 'get_by_id':
        result = get_service_by_id(data)
    elif action == 'get_categories':
        result = get_service_categories(data)
    else:
        result = error_response(f"Unknown action: {action}", 'UNKNOWN_ACTION')
    
    print(to_json(result))
