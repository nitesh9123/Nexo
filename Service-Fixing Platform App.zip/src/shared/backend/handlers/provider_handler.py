"""
Provider Handler
Handles provider-specific operations (job management, earnings, etc.)
"""

import sys
import os
import json
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.connection import get_db_connection
from utils.validator import validate_status_transition
from utils.response import success_response, error_response, format_booking_data, to_json
from config import ERROR_MESSAGES, SUCCESS_MESSAGES, BOOKING_STATUSES, APP_CONFIG

def get_new_requests(data):
    """
    Get all new service requests (not yet accepted)
    
    Args:
        data (dict): Optional filters
            - category: Filter by service category
    
    Returns:
        dict: Success or error response with requests list
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get bookings with status 'requested' and no provider assigned
        query = """
            SELECT * FROM booking_details 
            WHERE status = %s AND provider_id IS NULL
        """
        params = [BOOKING_STATUSES['REQUESTED']]
        
        # Add category filter if provided
        if data and 'category' in data and data['category']:
            query += " AND category = %s"
            params.append(data['category'])
        
        query += " ORDER BY created_at ASC"
        
        cursor.execute(query, params)
        requests = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        # Format requests
        formatted_requests = [format_booking_data(request) for request in requests]
        
        return success_response(data={'requests': formatted_requests})
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

def accept_request(data):
    """
    Accept a service request
    
    Args:
        data (dict): Request data
            - bookingId: Booking ID
            - providerId: Provider user ID
    
    Returns:
        dict: Success or error response
    """
    try:
        booking_id = data.get('bookingId')
        provider_id = data.get('providerId')
        
        if not booking_id or not provider_id:
            return error_response('Booking ID and Provider ID are required', 'VALIDATION_ERROR')
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Verify provider exists
        cursor.execute(
            "SELECT user_id FROM users WHERE user_id = %s AND user_type = 'provider'",
            (provider_id,)
        )
        if not cursor.fetchone():
            cursor.close()
            conn.close()
            return error_response('Invalid provider ID', 'INVALID_PROVIDER')
        
        # Get current booking
        cursor.execute("SELECT * FROM bookings WHERE booking_id = %s", (booking_id,))
        booking = cursor.fetchone()
        
        if not booking:
            cursor.close()
            conn.close()
            return error_response(ERROR_MESSAGES['booking_not_found'], 'BOOKING_NOT_FOUND')
        
        # Check if booking is still available
        if booking['status'] != BOOKING_STATUSES['REQUESTED']:
            cursor.close()
            conn.close()
            return error_response('This request is no longer available', 'REQUEST_UNAVAILABLE')
        
        if booking['provider_id'] is not None:
            cursor.close()
            conn.close()
            return error_response(ERROR_MESSAGES['provider_assigned'], 'PROVIDER_ASSIGNED')
        
        old_status = booking['status']
        
        # Update booking
        cursor.execute(
            """UPDATE bookings 
               SET provider_id = %s, status = %s 
               WHERE booking_id = %s""",
            (provider_id, BOOKING_STATUSES['ACCEPTED'], booking_id)
        )
        
        # Log status change
        cursor.execute(
            """INSERT INTO booking_status_history 
               (booking_id, old_status, new_status, changed_by, remarks)
               VALUES (%s, %s, %s, %s, %s)""",
            (booking_id, old_status, BOOKING_STATUSES['ACCEPTED'], provider_id, 'Provider accepted the request')
        )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return success_response(message='Request accepted successfully')
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

def get_provider_jobs(data):
    """
    Get all jobs for a provider
    
    Args:
        data (dict): Request data
            - providerId: Provider user ID
            - status: Filter by status (optional)
    
    Returns:
        dict: Success or error response with jobs list
    """
    try:
        provider_id = data.get('providerId')
        if not provider_id:
            return error_response('Provider ID is required', 'VALIDATION_ERROR')
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Build query
        query = "SELECT * FROM booking_details WHERE provider_id = %s"
        params = [provider_id]
        
        # Add status filter if provided
        if 'status' in data and data['status']:
            query += " AND status = %s"
            params.append(data['status'])
        
        query += " ORDER BY preferred_date ASC, preferred_time ASC"
        
        cursor.execute(query, params)
        jobs = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        # Format jobs
        formatted_jobs = [format_booking_data(job) for job in jobs]
        
        return success_response(data={'jobs': formatted_jobs})
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

def update_job_status(data):
    """
    Update job status
    
    Args:
        data (dict): Request data
            - bookingId: Booking ID
            - providerId: Provider user ID (for verification)
            - newStatus: New status
            - remarks: Optional remarks
    
    Returns:
        dict: Success or error response
    """
    try:
        booking_id = data.get('bookingId')
        provider_id = data.get('providerId')
        new_status = data.get('newStatus')
        
        if not booking_id or not provider_id or not new_status:
            return error_response('Booking ID, Provider ID, and New Status are required', 'VALIDATION_ERROR')
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get current booking
        cursor.execute(
            "SELECT * FROM bookings WHERE booking_id = %s AND provider_id = %s",
            (booking_id, provider_id)
        )
        booking = cursor.fetchone()
        
        if not booking:
            cursor.close()
            conn.close()
            return error_response(ERROR_MESSAGES['booking_not_found'], 'BOOKING_NOT_FOUND')
        
        old_status = booking['status']
        
        # Validate status transition
        is_valid, error_msg = validate_status_transition(old_status, new_status)
        if not is_valid:
            cursor.close()
            conn.close()
            return error_response(error_msg, 'INVALID_STATUS_TRANSITION')
        
        # Update booking status
        update_query = "UPDATE bookings SET status = %s"
        update_params = [new_status]
        
        # If completing, set completed_at timestamp
        if new_status == BOOKING_STATUSES['COMPLETED']:
            update_query += ", completed_at = %s"
            update_params.append(datetime.now())
        
        update_query += " WHERE booking_id = %s"
        update_params.append(booking_id)
        
        cursor.execute(update_query, update_params)
        
        # Log status change
        remarks = data.get('remarks', f'Status updated to {new_status}')
        cursor.execute(
            """INSERT INTO booking_status_history 
               (booking_id, old_status, new_status, changed_by, remarks)
               VALUES (%s, %s, %s, %s, %s)""",
            (booking_id, old_status, new_status, provider_id, remarks)
        )
        
        # If completed, create earning entry
        if new_status == BOOKING_STATUSES['COMPLETED']:
            total_amount = float(booking['total_amount'])
            platform_fee = total_amount * (APP_CONFIG['platform_fee_percentage'] / 100)
            net_amount = total_amount - platform_fee
            
            cursor.execute(
                """INSERT INTO provider_earnings 
                   (provider_id, booking_id, amount, platform_fee, net_amount)
                   VALUES (%s, %s, %s, %s, %s)""",
                (provider_id, booking_id, total_amount, platform_fee, net_amount)
            )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return success_response(message=SUCCESS_MESSAGES['status_updated'])
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

def get_provider_earnings(data):
    """
    Get provider earnings summary and history
    
    Args:
        data (dict): Request data
            - providerId: Provider user ID
    
    Returns:
        dict: Success or error response with earnings data
    """
    try:
        provider_id = data.get('providerId')
        if not provider_id:
            return error_response('Provider ID is required', 'VALIDATION_ERROR')
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get total earnings summary
        summary_query = """
            SELECT 
                COUNT(*) as total_jobs,
                COALESCE(SUM(amount), 0) as total_amount,
                COALESCE(SUM(platform_fee), 0) as total_platform_fee,
                COALESCE(SUM(net_amount), 0) as total_net_amount
            FROM provider_earnings
            WHERE provider_id = %s
        """
        cursor.execute(summary_query, (provider_id,))
        summary = cursor.fetchone()
        
        # Get earnings history with booking details
        history_query = """
            SELECT 
                e.*,
                b.booking_id,
                b.customer_id,
                b.preferred_date,
                b.service_id,
                s.service_name,
                s.category,
                u.full_name as customer_name
            FROM provider_earnings e
            JOIN bookings b ON e.booking_id = b.booking_id
            JOIN services s ON b.service_id = s.service_id
            JOIN users u ON b.customer_id = u.user_id
            WHERE e.provider_id = %s
            ORDER BY e.earned_at DESC
        """
        cursor.execute(history_query, (provider_id,))
        history = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        # Format data
        formatted_summary = {
            'total_jobs': summary['total_jobs'],
            'total_amount': float(summary['total_amount']),
            'total_platform_fee': float(summary['total_platform_fee']),
            'total_net_amount': float(summary['total_net_amount'])
        }
        
        formatted_history = []
        for entry in history:
            formatted_history.append({
                'earning_id': entry['earning_id'],
                'booking_id': entry['booking_id'],
                'service_name': entry['service_name'],
                'category': entry['category'],
                'customer_name': entry['customer_name'],
                'amount': float(entry['amount']),
                'platform_fee': float(entry['platform_fee']),
                'net_amount': float(entry['net_amount']),
                'earned_at': str(entry['earned_at']),
                'preferred_date': str(entry['preferred_date'])
            })
        
        return success_response(data={
            'summary': formatted_summary,
            'history': formatted_history
        })
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

# Main execution
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(to_json(error_response("Invalid arguments", 'INVALID_ARGS')))
        sys.exit(1)
    
    action = sys.argv[1]
    data = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
    
    result = None
    
    if action == 'get_new_requests':
        result = get_new_requests(data)
    elif action == 'accept_request':
        result = accept_request(data)
    elif action == 'get_jobs':
        result = get_provider_jobs(data)
    elif action == 'update_status':
        result = update_job_status(data)
    elif action == 'get_earnings':
        result = get_provider_earnings(data)
    else:
        result = error_response(f"Unknown action: {action}", 'UNKNOWN_ACTION')
    
    print(to_json(result))
