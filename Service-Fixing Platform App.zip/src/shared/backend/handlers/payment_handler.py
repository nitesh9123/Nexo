"""
Payment Handler
Handles simulated payment operations
"""

import sys
import os
import json

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.connection import get_db_connection
from utils.response import success_response, error_response, to_json
from config import ERROR_MESSAGES, SUCCESS_MESSAGES

def process_payment(data):
    """
    Process a simulated payment for a booking
    
    Args:
        data (dict): Payment data
            - bookingId: Booking ID
            - customerId: Customer ID (for verification)
            - paymentMethod: Payment method (cash, card, upi, etc.)
    
    Returns:
        dict: Success or error response
    """
    try:
        booking_id = data.get('bookingId')
        customer_id = data.get('customerId')
        payment_method = data.get('paymentMethod', 'cash')
        
        if not booking_id or not customer_id:
            return error_response('Booking ID and Customer ID are required', 'VALIDATION_ERROR')
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get booking
        cursor.execute(
            "SELECT * FROM bookings WHERE booking_id = %s AND customer_id = %s",
            (booking_id, customer_id)
        )
        booking = cursor.fetchone()
        
        if not booking:
            cursor.close()
            conn.close()
            return error_response(ERROR_MESSAGES['booking_not_found'], 'BOOKING_NOT_FOUND')
        
        # Check if already paid
        if booking['payment_status'] == 'paid':
            cursor.close()
            conn.close()
            return error_response('Payment already completed for this booking', 'ALREADY_PAID')
        
        # Check if booking is completed
        if booking['status'] != 'completed':
            cursor.close()
            conn.close()
            return error_response('Can only pay for completed services', 'INVALID_BOOKING_STATUS')
        
        # Update payment status (simulated)
        cursor.execute(
            """UPDATE bookings 
               SET payment_status = 'paid', payment_method = %s 
               WHERE booking_id = %s""",
            (payment_method, booking_id)
        )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return success_response(
            data={
                'booking_id': booking_id,
                'amount_paid': float(booking['total_amount']),
                'payment_method': payment_method
            },
            message=SUCCESS_MESSAGES['payment_success']
        )
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

def get_payment_status(data):
    """
    Get payment status for a booking
    
    Args:
        data (dict): Request data
            - bookingId: Booking ID
    
    Returns:
        dict: Success or error response with payment status
    """
    try:
        booking_id = data.get('bookingId')
        if not booking_id:
            return error_response('Booking ID is required', 'VALIDATION_ERROR')
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        cursor.execute(
            "SELECT payment_status, payment_method, total_amount FROM bookings WHERE booking_id = %s",
            (booking_id,)
        )
        booking = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        if not booking:
            return error_response(ERROR_MESSAGES['booking_not_found'], 'BOOKING_NOT_FOUND')
        
        return success_response(data={
            'payment_status': booking['payment_status'],
            'payment_method': booking['payment_method'],
            'total_amount': float(booking['total_amount'])
        })
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

# Main execution
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(to_json(error_response("Invalid arguments", 'INVALID_ARGS')))
        sys.exit(1)
    
    action = sys.argv[1]
    data = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
    
    result = None
    
    if action == 'process':
        result = process_payment(data)
    elif action == 'get_status':
        result = get_payment_status(data)
    else:
        result = error_response(f"Unknown action: {action}", 'UNKNOWN_ACTION')
    
    print(to_json(result))
