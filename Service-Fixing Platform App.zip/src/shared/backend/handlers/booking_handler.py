"""
Booking Handler
Handles booking-related operations for customers
"""

import sys
import os
import json
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.connection import get_db_connection
from utils.validator import validate_booking_data, sanitize_string
from utils.response import success_response, error_response, format_booking_data, to_json
from config import ERROR_MESSAGES, SUCCESS_MESSAGES, BOOKING_STATUSES

def create_booking(data):
    """
    Create a new service booking
    
    Args:
        data (dict): Booking data
            - customerId: Customer user ID
            - serviceId: Service ID
            - preferredDate: Preferred date (YYYY-MM-DD)
            - preferredTime: Preferred time (HH:MM)
            - address: Service address
            - city: City (optional)
            - additionalNotes: Additional notes (optional)
    
    Returns:
        dict: Success or error response with booking details
    """
    try:
        # Validate input
        is_valid, error_msg = validate_booking_data(data)
        if not is_valid:
            return error_response(error_msg, 'VALIDATION_ERROR')
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get service details to calculate total amount
        cursor.execute(
            "SELECT * FROM services WHERE service_id = %s AND is_active = TRUE",
            (data['serviceId'],)
        )
        service = cursor.fetchone()
        
        if not service:
            cursor.close()
            conn.close()
            return error_response(ERROR_MESSAGES['service_not_found'], 'SERVICE_NOT_FOUND')
        
        # Verify customer exists
        cursor.execute("SELECT user_id FROM users WHERE user_id = %s AND user_type = 'customer'", (data['customerId'],))
        if not cursor.fetchone():
            cursor.close()
            conn.close()
            return error_response('Invalid customer ID', 'INVALID_CUSTOMER')
        
        # Prepare booking data
        address = sanitize_string(data['address'])
        city = sanitize_string(data.get('city', ''), 50)
        additional_notes = sanitize_string(data.get('additionalNotes', ''))
        total_amount = float(service['base_price'])
        
        # Insert booking
        query = """
            INSERT INTO bookings 
            (customer_id, service_id, preferred_date, preferred_time, 
             address, city, additional_notes, status, total_amount, payment_status)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        
        values = (
            data['customerId'],
            data['serviceId'],
            data['preferredDate'],
            data['preferredTime'],
            address,
            city,
            additional_notes,
            BOOKING_STATUSES['REQUESTED'],
            total_amount,
            'pending'
        )
        
        cursor.execute(query, values)
        booking_id = cursor.lastrowid
        
        # Log status change in history
        history_query = """
            INSERT INTO booking_status_history 
            (booking_id, old_status, new_status, changed_by, remarks)
            VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(
            history_query,
            (booking_id, None, BOOKING_STATUSES['REQUESTED'], data['customerId'], 'Booking created')
        )
        
        conn.commit()
        
        # Get the created booking with all details
        cursor.execute("SELECT * FROM booking_details WHERE booking_id = %s", (booking_id,))
        booking = cursor.fetchone()
        
        cursor.close()
        conn.close()
        
        return success_response(
            data={'booking': format_booking_data(booking)},
            message=SUCCESS_MESSAGES['booking_created']
        )
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

def get_customer_bookings(data):
    """
    Get all bookings for a customer
    
    Args:
        data (dict): Request data
            - customerId: Customer user ID
            - status: Filter by status (optional)
    
    Returns:
        dict: Success or error response with bookings list
    """
    try:
        customer_id = data.get('customerId')
        if not customer_id:
            return error_response('Customer ID is required', 'VALIDATION_ERROR')
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Build query
        query = "SELECT * FROM booking_details WHERE customer_id = %s"
        params = [customer_id]
        
        # Add status filter if provided
        if 'status' in data and data['status']:
            query += " AND status = %s"
            params.append(data['status'])
        
        query += " ORDER BY created_at DESC"
        
        cursor.execute(query, params)
        bookings = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        # Format bookings
        formatted_bookings = [format_booking_data(booking) for booking in bookings]
        
        return success_response(data={'bookings': formatted_bookings})
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

def get_booking_by_id(data):
    """
    Get a specific booking by ID
    
    Args:
        data (dict): Request data
            - bookingId: Booking ID
            - customerId: Customer ID (for verification)
    
    Returns:
        dict: Success or error response with booking details
    """
    try:
        booking_id = data.get('bookingId')
        customer_id = data.get('customerId')
        
        if not booking_id:
            return error_response('Booking ID is required', 'VALIDATION_ERROR')
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get booking
        query = "SELECT * FROM booking_details WHERE booking_id = %s"
        params = [booking_id]
        
        # Verify customer ownership if customerId provided
        if customer_id:
            query += " AND customer_id = %s"
            params.append(customer_id)
        
        cursor.execute(query, params)
        booking = cursor.fetchone()
        
        # Get booking status history
        history_query = """
            SELECT h.*, u.full_name as changed_by_name
            FROM booking_status_history h
            LEFT JOIN users u ON h.changed_by = u.user_id
            WHERE h.booking_id = %s
            ORDER BY h.changed_at ASC
        """
        cursor.execute(history_query, (booking_id,))
        history = cursor.fetchall()
        
        cursor.close()
        conn.close()
        
        if not booking:
            return error_response(ERROR_MESSAGES['booking_not_found'], 'BOOKING_NOT_FOUND')
        
        # Format history
        formatted_history = []
        for entry in history:
            formatted_history.append({
                'old_status': entry['old_status'],
                'new_status': entry['new_status'],
                'changed_by_name': entry['changed_by_name'],
                'remarks': entry['remarks'],
                'changed_at': str(entry['changed_at'])
            })
        
        booking_data = format_booking_data(booking)
        booking_data['history'] = formatted_history
        
        return success_response(data={'booking': booking_data})
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

def cancel_booking(data):
    """
    Cancel a booking
    
    Args:
        data (dict): Request data
            - bookingId: Booking ID
            - customerId: Customer ID (for verification)
    
    Returns:
        dict: Success or error response
    """
    try:
        booking_id = data.get('bookingId')
        customer_id = data.get('customerId')
        
        if not booking_id or not customer_id:
            return error_response('Booking ID and Customer ID are required', 'VALIDATION_ERROR')
        
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        
        # Get current booking
        cursor.execute(
            "SELECT * FROM bookings WHERE booking_id = %s AND customer_id = %s",
            (booking_id, customer_id)
        )
        booking = cursor.fetchone()
        
        if not booking:
            cursor.close()
            conn.close()
            return error_response(ERROR_MESSAGES['booking_not_found'], 'BOOKING_NOT_FOUND')
        
        # Check if booking can be cancelled
        if booking['status'] in ['completed', 'cancelled']:
            cursor.close()
            conn.close()
            return error_response(f"Cannot cancel a {booking['status']} booking", 'INVALID_STATUS')
        
        old_status = booking['status']
        
        # Update booking status
        cursor.execute(
            "UPDATE bookings SET status = %s WHERE booking_id = %s",
            (BOOKING_STATUSES['CANCELLED'], booking_id)
        )
        
        # Log status change
        cursor.execute(
            """INSERT INTO booking_status_history 
               (booking_id, old_status, new_status, changed_by, remarks)
               VALUES (%s, %s, %s, %s, %s)""",
            (booking_id, old_status, BOOKING_STATUSES['CANCELLED'], customer_id, 'Cancelled by customer')
        )
        
        conn.commit()
        cursor.close()
        conn.close()
        
        return success_response(message='Booking cancelled successfully')
        
    except Exception as e:
        return error_response(f"{ERROR_MESSAGES['database_error']}: {str(e)}", 'DATABASE_ERROR')

# Main execution
if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(to_json(error_response("Invalid arguments", 'INVALID_ARGS')))
        sys.exit(1)
    
    action = sys.argv[1]
    data = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
    
    result = None
    
    if action == 'create':
        result = create_booking(data)
    elif action == 'get_customer_bookings':
        result = get_customer_bookings(data)
    elif action == 'get_by_id':
        result = get_booking_by_id(data)
    elif action == 'cancel':
        result = cancel_booking(data)
    else:
        result = error_response(f"Unknown action: {action}", 'UNKNOWN_ACTION')
    
    print(to_json(result))
