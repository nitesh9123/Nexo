"""
Data validation utilities
"""

import re
from datetime import datetime, date, time

def validate_email(email):
    """Validate email format"""
    if not email:
        return False
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def validate_phone(phone):
    """Validate phone number format"""
    if not phone:
        return True  # Phone is optional
    # Remove common formatting characters
    cleaned = re.sub(r'[\s\-\(\)]', '', phone)
    # Check if it's 10-15 digits
    return len(cleaned) >= 10 and len(cleaned) <= 15 and cleaned.isdigit()

def validate_password(password, min_length=6):
    """Validate password strength"""
    if not password:
        return False, "Password is required"
    if len(password) < min_length:
        return False, f"Password must be at least {min_length} characters"
    return True, "Valid"

def validate_required_fields(data, required_fields):
    """
    Validate that all required fields are present and non-empty
    
    Args:
        data (dict): Data dictionary
        required_fields (list): List of required field names
    
    Returns:
        tuple: (is_valid, error_message)
    """
    for field in required_fields:
        if field not in data or data[field] is None or str(data[field]).strip() == '':
            return False, f"Field '{field}' is required"
    return True, "Valid"

def validate_user_data(data, is_registration=True):
    """
    Validate user registration/login data
    
    Args:
        data (dict): User data
        is_registration (bool): True for registration, False for login
    
    Returns:
        tuple: (is_valid, error_message)
    """
    if is_registration:
        # Registration validation
        required = ['fullName', 'email', 'password']
        is_valid, msg = validate_required_fields(data, required)
        if not is_valid:
            return False, msg
        
        if not validate_email(data['email']):
            return False, "Invalid email format"
        
        is_valid, msg = validate_password(data['password'])
        if not is_valid:
            return False, msg
        
        if 'phone' in data and data['phone']:
            if not validate_phone(data['phone']):
                return False, "Invalid phone number format"
    else:
        # Login validation
        required = ['email', 'password']
        is_valid, msg = validate_required_fields(data, required)
        if not is_valid:
            return False, msg
        
        if not validate_email(data['email']):
            return False, "Invalid email format"
    
    return True, "Valid"

def validate_booking_data(data):
    """
    Validate booking data
    
    Args:
        data (dict): Booking data
    
    Returns:
        tuple: (is_valid, error_message)
    """
    required = ['customerId', 'serviceId', 'preferredDate', 'preferredTime', 'address']
    is_valid, msg = validate_required_fields(data, required)
    if not is_valid:
        return False, msg
    
    # Validate date format and ensure it's not in the past
    try:
        booking_date = datetime.strptime(data['preferredDate'], '%Y-%m-%d').date()
        today = date.today()
        
        if booking_date < today:
            return False, "Cannot book for past dates"
        
    except ValueError:
        return False, "Invalid date format. Use YYYY-MM-DD"
    
    # Validate time format
    try:
        datetime.strptime(data['preferredTime'], '%H:%M')
    except ValueError:
        return False, "Invalid time format. Use HH:MM"
    
    # Validate IDs are positive integers
    try:
        if int(data['customerId']) <= 0 or int(data['serviceId']) <= 0:
            return False, "Invalid customer or service ID"
    except (ValueError, TypeError):
        return False, "Invalid ID format"
    
    return True, "Valid"

def validate_status_transition(old_status, new_status):
    """
    Validate if status transition is allowed
    
    Args:
        old_status (str): Current status
        new_status (str): New status
    
    Returns:
        tuple: (is_valid, error_message)
    """
    allowed_transitions = {
        'requested': ['accepted', 'cancelled'],
        'accepted': ['in_progress', 'cancelled'],
        'in_progress': ['completed', 'cancelled'],
        'completed': [],  # Cannot change from completed
        'cancelled': []   # Cannot change from cancelled
    }
    
    if old_status not in allowed_transitions:
        return False, f"Invalid current status: {old_status}"
    
    if new_status not in allowed_transitions[old_status]:
        return False, f"Cannot change status from '{old_status}' to '{new_status}'"
    
    return True, "Valid"

def sanitize_string(value, max_length=None):
    """
    Sanitize string input
    
    Args:
        value (str): Input string
        max_length (int): Maximum allowed length
    
    Returns:
        str: Sanitized string
    """
    if not value:
        return ''
    
    # Remove leading/trailing whitespace
    sanitized = str(value).strip()
    
    # Limit length if specified
    if max_length and len(sanitized) > max_length:
        sanitized = sanitized[:max_length]
    
    return sanitized

def validate_positive_number(value, field_name="Value"):
    """
    Validate positive number
    
    Args:
        value: Number to validate
        field_name (str): Name of field for error message
    
    Returns:
        tuple: (is_valid, error_message)
    """
    try:
        num = float(value)
        if num <= 0:
            return False, f"{field_name} must be positive"
        return True, "Valid"
    except (ValueError, TypeError):
        return False, f"{field_name} must be a valid number"
