"""
Password hashing utilities using bcrypt
"""

import bcrypt

def hash_password(password):
    """
    Hash a password using bcrypt
    
    Args:
        password (str): Plain text password
    
    Returns:
        str: Hashed password
    """
    # Generate salt and hash password
    salt = bcrypt.gensalt(rounds=12)
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed.decode('utf-8')

def verify_password(password, hashed_password):
    """
    Verify a password against a hash
    
    Args:
        password (str): Plain text password to verify
        hashed_password (str): Hashed password from database
    
    Returns:
        bool: True if password matches, False otherwise
    """
    try:
        return bcrypt.checkpw(
            password.encode('utf-8'),
            hashed_password.encode('utf-8')
        )
    except Exception:
        return False

# For testing
if __name__ == '__main__':
    # Test hashing
    test_password = "password123"
    hashed = hash_password(test_password)
    print(f"Original: {test_password}")
    print(f"Hashed: {hashed}")
    print(f"Verification: {verify_password(test_password, hashed)}")
    print(f"Wrong password: {verify_password('wrongpass', hashed)}")
