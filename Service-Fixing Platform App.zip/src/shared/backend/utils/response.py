"""
Standardized JSON response utilities
"""

import json
from datetime import datetime, date, time
from decimal import Decimal

class DateTimeEncoder(json.JSONEncoder):
    """Custom JSON encoder for datetime objects"""
    def default(self, obj):
        if isinstance(obj, (datetime, date, time)):
            return obj.isoformat()
        if isinstance(obj, Decimal):
            return float(obj)
        return super().default(obj)

def success_response(data=None, message=None):
    """
    Create a success response
    
    Args:
        data: Response data (dict, list, etc.)
        message (str): Optional success message
    
    Returns:
        dict: Standardized success response
    """
    response = {
        'success': True,
        'data': data if data is not None else {},
    }
    
    if message:
        response['message'] = message
    
    return response

def error_response(error, code=None):
    """
    Create an error response
    
    Args:
        error (str): Error message
        code (str): Optional error code
    
    Returns:
        dict: Standardized error response
    """
    response = {
        'success': False,
        'error': error
    }
    
    if code:
        response['code'] = code
    
    return response

def to_json(data):
    """
    Convert data to JSON string with custom encoder
    
    Args:
        data: Data to convert
    
    Returns:
        str: JSON string
    """
    return json.dumps(data, cls=DateTimeEncoder, ensure_ascii=False)

def from_json(json_string):
    """
    Parse JSON string to Python object
    
    Args:
        json_string (str): JSON string
    
    Returns:
        dict/list: Parsed data
    """
    try:
        return json.loads(json_string)
    except json.JSONDecodeError as e:
        raise ValueError(f"Invalid JSON: {str(e)}")

def format_user_data(user):
    """
    Format user data for response (remove sensitive information)
    
    Args:
        user (dict): User data from database
    
    Returns:
        dict: Formatted user data
    """
    if not user:
        return None
    
    # Remove password hash from response
    safe_user = {k: v for k, v in user.items() if k != 'password_hash'}
    
    # Convert datetime objects to strings
    if 'created_at' in safe_user:
        safe_user['created_at'] = str(safe_user['created_at'])
    if 'updated_at' in safe_user:
        safe_user['updated_at'] = str(safe_user['updated_at'])
    
    return safe_user

def format_booking_data(booking):
    """
    Format booking data for response
    
    Args:
        booking (dict): Booking data from database
    
    Returns:
        dict: Formatted booking data
    """
    if not booking:
        return None
    
    formatted = booking.copy()
    
    # Convert date/time objects to strings
    if 'preferred_date' in formatted and formatted['preferred_date']:
        formatted['preferred_date'] = str(formatted['preferred_date'])
    if 'preferred_time' in formatted and formatted['preferred_time']:
        formatted['preferred_time'] = str(formatted['preferred_time'])
    if 'created_at' in formatted:
        formatted['created_at'] = str(formatted['created_at'])
    if 'updated_at' in formatted:
        formatted['updated_at'] = str(formatted['updated_at'])
    if 'completed_at' in formatted and formatted['completed_at']:
        formatted['completed_at'] = str(formatted['completed_at'])
    
    # Convert Decimal to float
    if 'total_amount' in formatted:
        formatted['total_amount'] = float(formatted['total_amount'])
    if 'base_price' in formatted:
        formatted['base_price'] = float(formatted['base_price'])
    
    return formatted

def format_service_data(service):
    """
    Format service data for response
    
    Args:
        service (dict): Service data from database
    
    Returns:
        dict: Formatted service data
    """
    if not service:
        return None
    
    formatted = service.copy()
    
    # Convert Decimal to float
    if 'base_price' in formatted:
        formatted['base_price'] = float(formatted['base_price'])
    
    # Convert datetime
    if 'created_at' in formatted:
        formatted['created_at'] = str(formatted['created_at'])
    if 'updated_at' in formatted:
        formatted['updated_at'] = str(formatted['updated_at'])
    
    return formatted
