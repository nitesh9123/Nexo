"""
Database connection module
Handles MySQL database connections
"""

import mysql.connector
from mysql.connector import Error
import sys
import os

# Add parent directory to path to import config
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config import DB_CONFIG

def get_db_connection():
    """
    Create and return a MySQL database connection
    
    Returns:
        connection: MySQL connection object
    
    Raises:
        Exception: If connection fails
    """
    try:
        connection = mysql.connector.connect(
            host=DB_CONFIG['host'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            database=DB_CONFIG['database'],
            port=DB_CONFIG['port'],
            charset=DB_CONFIG['charset']
        )
        
        if connection.is_connected():
            return connection
        else:
            raise Exception("Failed to connect to database")
            
    except Error as e:
        raise Exception(f"Database connection error: {str(e)}")

def execute_query(query, params=None, fetch_one=False, fetch_all=False, commit=False):
    """
    Execute a database query with error handling
    
    Args:
        query (str): SQL query to execute
        params (tuple): Query parameters
        fetch_one (bool): Fetch single row
        fetch_all (bool): Fetch all rows
        commit (bool): Commit transaction
    
    Returns:
        dict/list/int: Query result based on flags
    """
    connection = None
    cursor = None
    
    try:
        connection = get_db_connection()
        cursor = connection.cursor(dictionary=True)
        
        if params:
            cursor.execute(query, params)
        else:
            cursor.execute(query)
        
        result = None
        
        if fetch_one:
            result = cursor.fetchone()
        elif fetch_all:
            result = cursor.fetchall()
        elif commit:
            connection.commit()
            result = cursor.lastrowid if cursor.lastrowid else cursor.rowcount
        
        return result
        
    except Error as e:
        if connection:
            connection.rollback()
        raise Exception(f"Query execution error: {str(e)}")
        
    finally:
        if cursor:
            cursor.close()
        if connection and connection.is_connected():
            connection.close()

def test_connection():
    """Test database connection"""
    try:
        conn = get_db_connection()
        if conn.is_connected():
            db_info = conn.get_server_info()
            conn.close()
            return True, f"Connected to MySQL Server version {db_info}"
        return False, "Connection failed"
    except Exception as e:
        return False, str(e)

if __name__ == '__main__':
    # Test connection
    success, message = test_connection()
    print(f"Connection test: {message}")
