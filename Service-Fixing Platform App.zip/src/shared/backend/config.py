"""
Configuration file for database and application settings
"""

# Database Configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',  # Change this to your MySQL username
    'password': '',  # Change this to your MySQL password
    'database': 'service_platform',
    'port': 3306,
    'charset': 'utf8mb4',
    'autocommit': False
}

# Application Settings
APP_CONFIG = {
    'platform_fee_percentage': 10,  # Platform fee (10%)
    'max_booking_days_ahead': 90,   # Maximum days in future for booking
    'password_min_length': 6,
    'session_timeout_minutes': 30
}

# Status Configurations
BOOKING_STATUSES = {
    'REQUESTED': 'requested',
    'ACCEPTED': 'accepted',
    'IN_PROGRESS': 'in_progress',
    'COMPLETED': 'completed',
    'CANCELLED': 'cancelled'
}

PAYMENT_STATUSES = {
    'PENDING': 'pending',
    'PAID': 'paid'
}

USER_TYPES = {
    'CUSTOMER': 'customer',
    'PROVIDER': 'provider'
}

# Error Messages
ERROR_MESSAGES = {
    'invalid_credentials': 'Invalid email or password',
    'user_exists': 'User with this email already exists',
    'user_not_found': 'User not found',
    'service_not_found': 'Service not found',
    'booking_not_found': 'Booking not found',
    'invalid_data': 'Invalid data provided',
    'database_error': 'Database error occurred',
    'unauthorized': 'Unauthorized access',
    'invalid_status': 'Invalid status transition',
    'past_date': 'Cannot book for past dates',
    'provider_assigned': 'Provider already assigned to this booking'
}

# Success Messages
SUCCESS_MESSAGES = {
    'registration_success': 'Registration successful',
    'login_success': 'Login successful',
    'booking_created': 'Booking created successfully',
    'booking_updated': 'Booking updated successfully',
    'status_updated': 'Status updated successfully',
    'payment_success': 'Payment successful'
}
