/**
 * Sidebar Component
 * Navigation sidebar for the application
 */

import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Wrench, Calendar, User, CreditCard } from 'lucide-react';

const Sidebar = () => {
  const navItems = [
    { path: '/', icon: Home, label: 'Dashboard' },
    { path: '/services', icon: Wrench, label: 'Services' },
    { path: '/bookings', icon: Calendar, label: 'My Bookings' },
    { path: '/profile', icon: User, label: 'Profile' },
  ];

  return (
    <aside className="w-64 bg-white border-r border-gray-200 flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <Wrench className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="font-semibold text-gray-800">FixIt</h2>
            <p className="text-xs text-gray-500">Customer Portal</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            end={item.path === '/'}
            className={({ isActive }) =>
              `flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
                isActive
                  ? 'bg-blue-50 text-blue-600'
                  : 'text-gray-700 hover:bg-gray-50'
              }`
            }
          >
            <item.icon className="w-5 h-5" />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>

      {/* Help Section */}
      <div className="p-4 border-t border-gray-200">
        <div className="bg-blue-50 rounded-lg p-4">
          <p className="text-sm text-blue-900 mb-2">Need Help?</p>
          <p className="text-xs text-blue-700 mb-3">
            Contact our support team for assistance
          </p>
          <button className="w-full bg-blue-600 text-white text-sm py-2 rounded hover:bg-blue-700 transition-colors">
            Get Support
          </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
