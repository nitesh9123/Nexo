/**
 * API Utility Functions
 * Wrapper around window.api with error handling
 */

class APIError extends Error {
  constructor(message, code) {
    super(message);
    this.code = code;
    this.name = 'APIError';
  }
}

const handleResponse = (response) => {
  if (!response) {
    throw new APIError('No response from server', 'NO_RESPONSE');
  }

  if (!response.success) {
    throw new APIError(
      response.error || 'An error occurred',
      response.code || 'UNKNOWN_ERROR'
    );
  }

  return response.data;
};

export const api = {
  // Authentication
  register: async (userData) => {
    const response = await window.api.register(userData);
    return handleResponse(response);
  },

  login: async (credentials) => {
    const response = await window.api.login(credentials);
    return handleResponse(response);
  },

  getProfile: async (userId) => {
    const response = await window.api.getProfile(userId);
    return handleResponse(response);
  },

  // Services
  getServices: async (filters = {}) => {
    const response = await window.api.getServices(filters);
    return handleResponse(response);
  },

  getServiceById: async (serviceId) => {
    const response = await window.api.getServiceById(serviceId);
    return handleResponse(response);
  },

  getServiceCategories: async () => {
    const response = await window.api.getServiceCategories();
    return handleResponse(response);
  },

  // Bookings
  createBooking: async (bookingData) => {
    const response = await window.api.createBooking(bookingData);
    return handleResponse(response);
  },

  getCustomerBookings: async (customerId, status = null) => {
    const response = await window.api.getCustomerBookings(customerId, status);
    return handleResponse(response);
  },

  getBookingById: async (bookingId, customerId) => {
    const response = await window.api.getBookingById(bookingId, customerId);
    return handleResponse(response);
  },

  cancelBooking: async (bookingId, customerId) => {
    const response = await window.api.cancelBooking(bookingId, customerId);
    return handleResponse(response);
  },

  // Payments
  processPayment: async (paymentData) => {
    const response = await window.api.processPayment(paymentData);
    return handleResponse(response);
  },

  getPaymentStatus: async (bookingId) => {
    const response = await window.api.getPaymentStatus(bookingId);
    return handleResponse(response);
  },
};

export { APIError };
