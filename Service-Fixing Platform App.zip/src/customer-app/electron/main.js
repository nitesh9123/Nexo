/**
 * Electron Main Process
 * Handles window creation and IPC communication with Python backend
 */

const { app, BrowserWindow, ipcMain } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const isDev = require('electron-is-dev');

let mainWindow;

// Python backend path
const BACKEND_PATH = path.join(__dirname, '../../shared/backend/handlers');

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1024,
    minHeight: 768,
    frame: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      enableRemoteModule: false
    },
    title: 'Service Fixing Platform - Customer',
    icon: path.join(__dirname, '../public/icon.png')
  });

  // Load React app
  const startUrl = isDev
    ? 'http://localhost:3000'
    : `file://${path.join(__dirname, '../build/index.html')}`;
  
  mainWindow.loadURL(startUrl);

  // Open DevTools in development
  if (isDev) {
    mainWindow.webContents.openDevTools();
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// Helper function to execute Python scripts
function executePython(scriptName, action, data) {
  return new Promise((resolve, reject) => {
    const pythonPath = 'python'; // Assumes Python is in PATH
    const scriptPath = path.join(BACKEND_PATH, scriptName);
    const args = [scriptPath, action, JSON.stringify(data || {})];

    console.log(`Executing: ${pythonPath} ${scriptPath} ${action}`);

    const pythonProcess = spawn(pythonPath, args);

    let result = '';
    let error = '';

    pythonProcess.stdout.on('data', (data) => {
      result += data.toString();
    });

    pythonProcess.stderr.on('data', (data) => {
      error += data.toString();
      console.error('Python stderr:', data.toString());
    });

    pythonProcess.on('close', (code) => {
      if (code !== 0) {
        console.error('Python process error:', error);
        reject(new Error(error || 'Python process failed'));
      } else {
        try {
          const parsed = JSON.parse(result);
          resolve(parsed);
        } catch (e) {
          console.error('JSON parse error:', result);
          reject(new Error('Invalid JSON response from Python'));
        }
      }
    });

    pythonProcess.on('error', (err) => {
      console.error('Failed to start Python process:', err);
      reject(err);
    });
  });
}

// IPC Handlers - Authentication
ipcMain.handle('user-register', async (event, userData) => {
  return executePython('auth_handler.py', 'register', userData);
});

ipcMain.handle('user-login', async (event, credentials) => {
  return executePython('auth_handler.py', 'login', credentials);
});

ipcMain.handle('get-profile', async (event, userId) => {
  return executePython('auth_handler.py', 'profile', { userId });
});

// IPC Handlers - Services
ipcMain.handle('get-services', async (event, filters) => {
  return executePython('service_handler.py', 'get_all', filters);
});

ipcMain.handle('get-service-by-id', async (event, serviceId) => {
  return executePython('service_handler.py', 'get_by_id', { serviceId });
});

ipcMain.handle('get-service-categories', async (event) => {
  return executePython('service_handler.py', 'get_categories', {});
});

// IPC Handlers - Bookings
ipcMain.handle('create-booking', async (event, bookingData) => {
  return executePython('booking_handler.py', 'create', bookingData);
});

ipcMain.handle('get-customer-bookings', async (event, data) => {
  return executePython('booking_handler.py', 'get_customer_bookings', data);
});

ipcMain.handle('get-booking-by-id', async (event, data) => {
  return executePython('booking_handler.py', 'get_by_id', data);
});

ipcMain.handle('cancel-booking', async (event, data) => {
  return executePython('booking_handler.py', 'cancel', data);
});

// IPC Handlers - Payments
ipcMain.handle('process-payment', async (event, paymentData) => {
  return executePython('payment_handler.py', 'process', paymentData);
});

ipcMain.handle('get-payment-status', async (event, data) => {
  return executePython('payment_handler.py', 'get_status', data);
});

// Window controls
ipcMain.on('minimize-window', () => {
  if (mainWindow) mainWindow.minimize();
});

ipcMain.on('maximize-window', () => {
  if (mainWindow) {
    if (mainWindow.isMaximized()) {
      mainWindow.unmaximize();
    } else {
      mainWindow.maximize();
    }
  }
});

ipcMain.on('close-window', () => {
  if (mainWindow) mainWindow.close();
});
