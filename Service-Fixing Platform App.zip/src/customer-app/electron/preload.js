/**
 * Electron Preload Script
 * Exposes secure API to the renderer process
 */

const { contextBridge, ipcRenderer } = require('electron');

// Expose protected methods that allow the renderer process to use
// the ipcRenderer without exposing the entire object
contextBridge.exposeInMainWorld('api', {
  // Authentication
  register: (userData) => ipcRenderer.invoke('user-register', userData),
  login: (credentials) => ipcRenderer.invoke('user-login', credentials),
  getProfile: (userId) => ipcRenderer.invoke('get-profile', userId),
  
  // Services
  getServices: (filters) => ipcRenderer.invoke('get-services', filters),
  getServiceById: (serviceId) => ipcRenderer.invoke('get-service-by-id', serviceId),
  getServiceCategories: () => ipcRenderer.invoke('get-service-categories'),
  
  // Bookings
  createBooking: (bookingData) => ipcRenderer.invoke('create-booking', bookingData),
  getCustomerBookings: (customerId, status) => ipcRenderer.invoke('get-customer-bookings', { customerId, status }),
  getBookingById: (bookingId, customerId) => ipcRenderer.invoke('get-booking-by-id', { bookingId, customerId }),
  cancelBooking: (bookingId, customerId) => ipcRenderer.invoke('cancel-booking', { bookingId, customerId }),
  
  // Payments
  processPayment: (paymentData) => ipcRenderer.invoke('process-payment', paymentData),
  getPaymentStatus: (bookingId) => ipcRenderer.invoke('get-payment-status', { bookingId }),
  
  // Platform info
  platform: process.platform,
  
  // Window controls
  minimizeWindow: () => ipcRenderer.send('minimize-window'),
  maximizeWindow: () => ipcRenderer.send('maximize-window'),
  closeWindow: () => ipcRenderer.send('close-window'),
});
