import { Monitor, ArrowRight, Database, Cpu } from 'lucide-react';

export function ArchitectureOverview() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">System Architecture Overview</h2>
        <p className="mt-2 text-gray-600">
          A comprehensive desktop application architecture for a service-fixing platform
        </p>
      </div>

      {/* High-Level Architecture */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">High-Level Architecture</h3>
        
        <div className="space-y-6">
          {/* Architecture Diagram */}
          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg p-8 border border-blue-200">
            <div className="flex items-center justify-around">
              {/* Layer 1: UI */}
              <div className="flex flex-col items-center gap-3">
                <div className="w-32 h-32 bg-white rounded-lg shadow-lg flex items-center justify-center border-2 border-blue-500">
                  <div className="text-center">
                    <Monitor className="w-12 h-12 text-blue-600 mx-auto mb-2" />
                    <p className="text-sm font-bold text-gray-900">React UI</p>
                    <p className="text-xs text-gray-600">Presentation</p>
                  </div>
                </div>
                <p className="text-xs text-gray-700 font-medium">Frontend Layer</p>
              </div>

              <ArrowRight className="w-8 h-8 text-gray-400" />

              {/* Layer 2: Electron */}
              <div className="flex flex-col items-center gap-3">
                <div className="w-32 h-32 bg-white rounded-lg shadow-lg flex items-center justify-center border-2 border-green-500">
                  <div className="text-center">
                    <div className="w-12 h-12 bg-green-100 rounded mx-auto mb-2 flex items-center justify-center">
                      <span className="text-xl font-bold text-green-700">E</span>
                    </div>
                    <p className="text-sm font-bold text-gray-900">Electron</p>
                    <p className="text-xs text-gray-600">IPC Bridge</p>
                  </div>
                </div>
                <p className="text-xs text-gray-700 font-medium">Desktop Layer</p>
              </div>

              <ArrowRight className="w-8 h-8 text-gray-400" />

              {/* Layer 3: Python */}
              <div className="flex flex-col items-center gap-3">
                <div className="w-32 h-32 bg-white rounded-lg shadow-lg flex items-center justify-center border-2 border-yellow-500">
                  <div className="text-center">
                    <Cpu className="w-12 h-12 text-yellow-600 mx-auto mb-2" />
                    <p className="text-sm font-bold text-gray-900">Python</p>
                    <p className="text-xs text-gray-600">Business Logic</p>
                  </div>
                </div>
                <p className="text-xs text-gray-700 font-medium">Backend Layer</p>
              </div>

              <ArrowRight className="w-8 h-8 text-gray-400" />

              {/* Layer 4: Database */}
              <div className="flex flex-col items-center gap-3">
                <div className="w-32 h-32 bg-white rounded-lg shadow-lg flex items-center justify-center border-2 border-purple-500">
                  <div className="text-center">
                    <Database className="w-12 h-12 text-purple-600 mx-auto mb-2" />
                    <p className="text-sm font-bold text-gray-900">MySQL</p>
                    <p className="text-xs text-gray-600">Data Storage</p>
                  </div>
                </div>
                <p className="text-xs text-gray-700 font-medium">Data Layer</p>
              </div>
            </div>
          </div>

          {/* Key Principles */}
          <div className="grid grid-cols-2 gap-4 mt-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-bold text-gray-900 mb-2">Two Separate Applications</h4>
              <ul className="space-y-1 text-sm text-gray-700">
                <li>• Customer Desktop App</li>
                <li>• Service Provider Desktop App</li>
                <li>• No role-based login (independent apps)</li>
                <li>• Shared database backend</li>
              </ul>
            </div>

            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h4 className="font-bold text-gray-900 mb-2">Clean Architecture</h4>
              <ul className="space-y-1 text-sm text-gray-700">
                <li>• Separation of concerns</li>
                <li>• Modular components</li>
                <li>• Easy to maintain and extend</li>
                <li>• Simple for college project demo</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Why Desktop Application? */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Why Desktop Application?</h3>
        
        <div className="grid grid-cols-2 gap-6">
          <div>
            <h4 className="font-bold text-gray-900 mb-3">Benefits</h4>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-green-600 font-bold">✓</span>
                <span><strong>Offline Capability:</strong> Works without internet (local database)</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600 font-bold">✓</span>
                <span><strong>Better Performance:</strong> Direct system access, no network latency</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600 font-bold">✓</span>
                <span><strong>System Integration:</strong> Can access file system, notifications</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600 font-bold">✓</span>
                <span><strong>Security:</strong> Data stored locally, no public server exposure</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-green-600 font-bold">✓</span>
                <span><strong>Professional:</strong> Demonstrates full-stack desktop development</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-gray-900 mb-3">College Project Advantages</h4>
            <ul className="space-y-2 text-sm text-gray-700">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 font-bold">→</span>
                <span>No deployment/hosting required</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 font-bold">→</span>
                <span>Easy to demonstrate in viva</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 font-bold">→</span>
                <span>Shows knowledge of multiple technologies</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 font-bold">→</span>
                <span>Clear separation between frontend and backend</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 font-bold">→</span>
                <span>Can run entirely on local machine</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Communication Flow */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Communication Architecture</h3>
        
        <div className="bg-gray-50 rounded-lg p-6 border border-gray-300">
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="bg-blue-100 px-4 py-2 rounded font-mono text-sm text-blue-900 border border-blue-300">
                React Component
              </div>
              <ArrowRight className="w-5 h-5 text-gray-500" />
              <div className="bg-gray-100 px-3 py-1 rounded text-xs text-gray-700 border border-gray-400">
                window.electronAPI.invoke()
              </div>
              <ArrowRight className="w-5 h-5 text-gray-500" />
              <div className="bg-green-100 px-4 py-2 rounded font-mono text-sm text-green-900 border border-green-300">
                Electron Main Process
              </div>
            </div>

            <div className="flex items-center gap-4 ml-12">
              <ArrowRight className="w-5 h-5 text-gray-500 rotate-90" />
            </div>

            <div className="flex items-center gap-4">
              <div className="bg-yellow-100 px-4 py-2 rounded font-mono text-sm text-yellow-900 border border-yellow-300">
                Python Script
              </div>
              <ArrowRight className="w-5 h-5 text-gray-500" />
              <div className="bg-gray-100 px-3 py-1 rounded text-xs text-gray-700 border border-gray-400">
                MySQL Connector
              </div>
              <ArrowRight className="w-5 h-5 text-gray-500" />
              <div className="bg-purple-100 px-4 py-2 rounded font-mono text-sm text-purple-900 border border-purple-300">
                MySQL Database
              </div>
            </div>

            <div className="mt-6 p-4 bg-amber-50 border border-amber-300 rounded">
              <p className="text-sm text-amber-900">
                <strong>Key Point:</strong> No HTTP/REST APIs are used. Communication happens via Electron's IPC (Inter-Process Communication) 
                which calls Python scripts using child_process.spawn() or similar mechanisms.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Design Principles */}
      <div className="bg-gradient-to-r from-indigo-50 to-blue-50 rounded-lg border border-indigo-200 p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Design Principles for Viva Success</h3>
        
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-white rounded-lg p-4 border border-gray-200">
            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center mb-3">
              <span className="text-blue-700 font-bold">1</span>
            </div>
            <h4 className="font-bold text-gray-900 mb-2">Simplicity</h4>
            <p className="text-sm text-gray-700">
              Clear, understandable code that you can explain confidently
            </p>
          </div>

          <div className="bg-white rounded-lg p-4 border border-gray-200">
            <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center mb-3">
              <span className="text-green-700 font-bold">2</span>
            </div>
            <h4 className="font-bold text-gray-900 mb-2">Modularity</h4>
            <p className="text-sm text-gray-700">
              Separate files for each feature, easy to navigate and demonstrate
            </p>
          </div>

          <div className="bg-white rounded-lg p-4 border border-gray-200">
            <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center mb-3">
              <span className="text-purple-700 font-bold">3</span>
            </div>
            <h4 className="font-bold text-gray-900 mb-2">Realism</h4>
            <p className="text-sm text-gray-700">
              Real-world features that show practical application development
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
