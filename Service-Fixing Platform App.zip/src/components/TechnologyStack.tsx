import { Code2, Layers, Server, Database } from 'lucide-react';

export function TechnologyStack() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Technology Stack</h2>
        <p className="mt-2 text-gray-600">
          Detailed breakdown of technologies and their roles
        </p>
      </div>

      {/* Technology Layers */}
      <div className="space-y-4">
        {/* React */}
        <div className="bg-white rounded-lg border-2 border-blue-300 overflow-hidden">
          <div className="bg-blue-600 px-6 py-4 flex items-center gap-3">
            <Code2 className="w-6 h-6 text-white" />
            <h3 className="text-xl font-bold text-white">React (Frontend)</h3>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Purpose</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• User Interface rendering</li>
                  <li>• Component-based architecture</li>
                  <li>• State management (useState, useEffect)</li>
                  <li>• User interaction handling</li>
                  <li>• Form validation and data display</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Key Libraries</h4>
                <div className="space-y-2">
                  <div className="bg-blue-50 px-3 py-2 rounded border border-blue-200">
                    <code className="text-sm text-blue-900 font-mono">react</code>
                    <p className="text-xs text-gray-600 mt-1">Core framework</p>
                  </div>
                  <div className="bg-blue-50 px-3 py-2 rounded border border-blue-200">
                    <code className="text-sm text-blue-900 font-mono">react-dom</code>
                    <p className="text-xs text-gray-600 mt-1">DOM rendering</p>
                  </div>
                  <div className="bg-blue-50 px-3 py-2 rounded border border-blue-200">
                    <code className="text-sm text-blue-900 font-mono">lucide-react</code>
                    <p className="text-xs text-gray-600 mt-1">Icons (optional)</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded">
              <p className="text-sm text-gray-700">
                <strong>Why React?</strong> Modern, component-based, easy to learn, excellent for building interactive UIs,
                integrates seamlessly with Electron.
              </p>
            </div>
          </div>
        </div>

        {/* Electron */}
        <div className="bg-white rounded-lg border-2 border-green-300 overflow-hidden">
          <div className="bg-green-600 px-6 py-4 flex items-center gap-3">
            <Layers className="w-6 h-6 text-white" />
            <h3 className="text-xl font-bold text-white">Electron (Desktop Framework)</h3>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Purpose</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Converts web app to desktop application</li>
                  <li>• Provides native OS integration</li>
                  <li>• Handles IPC (Inter-Process Communication)</li>
                  <li>• Manages main and renderer processes</li>
                  <li>• Creates executable (.exe) file</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Core Components</h4>
                <div className="space-y-2">
                  <div className="bg-green-50 px-3 py-2 rounded border border-green-200">
                    <code className="text-sm text-green-900 font-mono">main.js</code>
                    <p className="text-xs text-gray-600 mt-1">Main process (Node.js)</p>
                  </div>
                  <div className="bg-green-50 px-3 py-2 rounded border border-green-200">
                    <code className="text-sm text-green-900 font-mono">preload.js</code>
                    <p className="text-xs text-gray-600 mt-1">Secure bridge between UI and backend</p>
                  </div>
                  <div className="bg-green-50 px-3 py-2 rounded border border-green-200">
                    <code className="text-sm text-green-900 font-mono">renderer</code>
                    <p className="text-xs text-gray-600 mt-1">React app (Chromium)</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 space-y-3">
              <div className="p-4 bg-green-50 border border-green-200 rounded">
                <h5 className="font-bold text-gray-900 mb-2 text-sm">IPC Communication</h5>
                <div className="bg-white p-3 rounded border border-gray-300 font-mono text-xs">
                  <div className="text-gray-700">
                    <span className="text-blue-600">// In React</span><br/>
                    <span className="text-purple-600">window.electronAPI</span>.invoke(<span className="text-green-600">'login'</span>, userData);<br/><br/>
                    <span className="text-blue-600">// In main.js</span><br/>
                    ipcMain.handle(<span className="text-green-600">'login'</span>, <span className="text-purple-600">async</span> (event, data) =&gt; &#123;<br/>
                    &nbsp;&nbsp;<span className="text-blue-600">// Call Python script</span><br/>
                    &#125;);
                  </div>
                </div>
              </div>

              <div className="p-4 bg-green-50 border border-green-200 rounded">
                <p className="text-sm text-gray-700">
                  <strong>Why Electron?</strong> Cross-platform desktop apps with web technologies, large community,
                  well-documented, used by VS Code, Slack, Discord.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Python */}
        <div className="bg-white rounded-lg border-2 border-yellow-300 overflow-hidden">
          <div className="bg-yellow-600 px-6 py-4 flex items-center gap-3">
            <Server className="w-6 h-6 text-white" />
            <h3 className="text-xl font-bold text-white">Python (Backend Logic)</h3>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Purpose</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Business logic implementation</li>
                  <li>• Database operations (CRUD)</li>
                  <li>• Data validation and processing</li>
                  <li>• Authentication logic</li>
                  <li>• Booking management algorithms</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Key Libraries</h4>
                <div className="space-y-2">
                  <div className="bg-yellow-50 px-3 py-2 rounded border border-yellow-200">
                    <code className="text-sm text-yellow-900 font-mono">mysql-connector-python</code>
                    <p className="text-xs text-gray-600 mt-1">MySQL database connection</p>
                  </div>
                  <div className="bg-yellow-50 px-3 py-2 rounded border border-yellow-200">
                    <code className="text-sm text-yellow-900 font-mono">json</code>
                    <p className="text-xs text-gray-600 mt-1">Data serialization</p>
                  </div>
                  <div className="bg-yellow-50 px-3 py-2 rounded border border-yellow-200">
                    <code className="text-sm text-yellow-900 font-mono">hashlib</code>
                    <p className="text-xs text-gray-600 mt-1">Password hashing</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 space-y-3">
              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded">
                <h5 className="font-bold text-gray-900 mb-2 text-sm">How Electron Calls Python</h5>
                <div className="bg-white p-3 rounded border border-gray-300 font-mono text-xs">
                  <div className="text-gray-700">
                    <span className="text-blue-600">const</span> &#123; spawn &#125; = <span className="text-purple-600">require</span>(<span className="text-green-600">'child_process'</span>);<br/><br/>
                    <span className="text-blue-600">const</span> python = spawn(<span className="text-green-600">'python'</span>, [<span className="text-green-600">'backend/auth.py'</span>, args]);<br/>
                    python.stdout.on(<span className="text-green-600">'data'</span>, (data) =&gt; &#123;<br/>
                    &nbsp;&nbsp;<span className="text-blue-600">const</span> result = JSON.parse(data);<br/>
                    &#125;);
                  </div>
                </div>
              </div>

              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded">
                <p className="text-sm text-gray-700">
                  <strong>Why Python (no Flask)?</strong> Simpler architecture, no web server needed, direct script execution,
                  easier to debug, perfect for desktop apps.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* MySQL */}
        <div className="bg-white rounded-lg border-2 border-purple-300 overflow-hidden">
          <div className="bg-purple-600 px-6 py-4 flex items-center gap-3">
            <Database className="w-6 h-6 text-white" />
            <h3 className="text-xl font-bold text-white">MySQL (Database)</h3>
          </div>
          <div className="p-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Purpose</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• Persistent data storage</li>
                  <li>• User credentials management</li>
                  <li>• Service and booking records</li>
                  <li>• Transaction history</li>
                  <li>• Relational data integrity</li>
                </ul>
              </div>
              <div>
                <h4 className="font-bold text-gray-900 mb-3">Setup Requirements</h4>
                <div className="space-y-2">
                  <div className="bg-purple-50 px-3 py-2 rounded border border-purple-200">
                    <p className="text-sm text-purple-900 font-medium">MySQL Server 8.0+</p>
                    <p className="text-xs text-gray-600 mt-1">Local installation</p>
                  </div>
                  <div className="bg-purple-50 px-3 py-2 rounded border border-purple-200">
                    <p className="text-sm text-purple-900 font-medium">MySQL Workbench</p>
                    <p className="text-xs text-gray-600 mt-1">Database administration</p>
                  </div>
                  <div className="bg-purple-50 px-3 py-2 rounded border border-purple-200">
                    <p className="text-sm text-purple-900 font-medium">Database Schema</p>
                    <p className="text-xs text-gray-600 mt-1">Initial setup script</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 space-y-3">
              <div className="p-4 bg-purple-50 border border-purple-200 rounded">
                <h5 className="font-bold text-gray-900 mb-2 text-sm">Connection Configuration</h5>
                <div className="bg-white p-3 rounded border border-gray-300 font-mono text-xs">
                  <div className="text-gray-700">
                    <span className="text-blue-600">import</span> mysql.connector<br/><br/>
                    db = mysql.connector.connect(<br/>
                    &nbsp;&nbsp;host=<span className="text-green-600">"localhost"</span>,<br/>
                    &nbsp;&nbsp;user=<span className="text-green-600">"root"</span>,<br/>
                    &nbsp;&nbsp;password=<span className="text-green-600">"your_password"</span>,<br/>
                    &nbsp;&nbsp;database=<span className="text-green-600">"service_platform"</span><br/>
                    )
                  </div>
                </div>
              </div>

              <div className="p-4 bg-purple-50 border border-purple-200 rounded">
                <p className="text-sm text-gray-700">
                  <strong>Why MySQL?</strong> Industry-standard, reliable, excellent for relational data,
                  strong ACID compliance, free and well-documented.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Technology Integration Summary */}
      <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-lg p-6 text-white">
        <h3 className="text-xl font-bold mb-4">How Everything Works Together</h3>
        
        <div className="space-y-4">
          <div className="flex items-start gap-4">
            <div className="bg-white text-gray-900 rounded-full w-8 h-8 flex items-center justify-center font-bold flex-shrink-0">
              1
            </div>
            <div>
              <p className="font-medium mb-1">User interacts with React UI (clicks button, fills form)</p>
              <p className="text-sm text-gray-300">React components handle UI state and validation</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="bg-white text-gray-900 rounded-full w-8 h-8 flex items-center justify-center font-bold flex-shrink-0">
              2
            </div>
            <div>
              <p className="font-medium mb-1">React calls Electron IPC API via preload script</p>
              <p className="text-sm text-gray-300">Secure communication through contextBridge</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="bg-white text-gray-900 rounded-full w-8 h-8 flex items-center justify-center font-bold flex-shrink-0">
              3
            </div>
            <div>
              <p className="font-medium mb-1">Electron main process receives IPC message</p>
              <p className="text-sm text-gray-300">Spawns Python script as child process with arguments</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="bg-white text-gray-900 rounded-full w-8 h-8 flex items-center justify-center font-bold flex-shrink-0">
              4
            </div>
            <div>
              <p className="font-medium mb-1">Python script processes business logic</p>
              <p className="text-sm text-gray-300">Validates data, performs calculations, handles errors</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="bg-white text-gray-900 rounded-full w-8 h-8 flex items-center justify-center font-bold flex-shrink-0">
              5
            </div>
            <div>
              <p className="font-medium mb-1">Python connects to MySQL and executes queries</p>
              <p className="text-sm text-gray-300">CRUD operations, transactions, data retrieval</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="bg-white text-gray-900 rounded-full w-8 h-8 flex items-center justify-center font-bold flex-shrink-0">
              6
            </div>
            <div>
              <p className="font-medium mb-1">Python returns JSON response to stdout</p>
              <p className="text-sm text-gray-300">Electron captures output and sends back to React</p>
            </div>
          </div>

          <div className="flex items-start gap-4">
            <div className="bg-white text-gray-900 rounded-full w-8 h-8 flex items-center justify-center font-bold flex-shrink-0">
              7
            </div>
            <div>
              <p className="font-medium mb-1">React updates UI with response data</p>
              <p className="text-sm text-gray-300">Display results, show errors, update state</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
