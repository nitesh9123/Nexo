import { UserPlus, LogIn, Search, Calendar, Send, CheckCircle, History, CreditCard } from 'lucide-react';

export function CustomerAppFeatures() {
  const features = [
    {
      icon: UserPlus,
      title: 'User Registration',
      description: 'Create new customer account',
      details: [
        'Full name, email, phone, address',
        'Password (hashed with SHA-256)',
        'Email validation',
        'Duplicate email check',
      ],
      workflow: [
        'User fills registration form',
        'React validates input',
        'Calls Python register.py script',
        'Python validates and hashes password',
        'Inserts into customers table',
        'Returns success/error',
      ],
      dbTable: 'customers',
      color: 'blue',
    },
    {
      icon: LogIn,
      title: 'User Login',
      description: 'Authenticate customer',
      details: [
        'Email and password authentication',
        'Password hash comparison',
        'Session token generation',
        'Store logged-in user data',
      ],
      workflow: [
        'User enters credentials',
        'Python queries database',
        'Compares password hash',
        'Returns user details if valid',
        'React stores user session',
        'Redirects to dashboard',
      ],
      dbTable: 'customers',
      color: 'green',
    },
    {
      icon: Search,
      title: 'Browse Services',
      description: 'View available repair services',
      details: [
        'List all service categories',
        'Service name, description, price',
        'Filter by category',
        'Search functionality',
      ],
      workflow: [
        'Load services on dashboard',
        'Python fetches from services table',
        'Returns JSON array',
        'React displays in grid/list',
        'User can click to select',
      ],
      dbTable: 'services',
      color: 'purple',
    },
    {
      icon: Calendar,
      title: 'Select Date & Time',
      description: 'Choose preferred appointment',
      details: [
        'Date picker component',
        'Time slot selection',
        'Check provider availability',
        'Validate future dates only',
      ],
      workflow: [
        'User selects service',
        'Opens date/time picker',
        'Validates selection',
        'Stores in booking state',
        'Proceeds to confirmation',
      ],
      dbTable: 'bookings',
      color: 'yellow',
    },
    {
      icon: Send,
      title: 'Place Service Request',
      description: 'Submit booking',
      details: [
        'Customer ID, Service ID',
        'Preferred date and time',
        'Additional notes/description',
        'Initial status: "Requested"',
      ],
      workflow: [
        'User confirms booking',
        'Python creates_booking.py',
        'Inserts into bookings table',
        'Sets status to "Requested"',
        'Returns booking ID',
        'Shows confirmation',
      ],
      dbTable: 'bookings',
      color: 'indigo',
    },
    {
      icon: CheckCircle,
      title: 'Track Request Status',
      description: 'Monitor booking progress',
      details: [
        'Requested (waiting for provider)',
        'Accepted (provider confirmed)',
        'In Progress (work started)',
        'Completed (job finished)',
      ],
      workflow: [
        'Load customer bookings',
        'Python fetches with JOIN',
        'Includes service details',
        'Displays status badge',
        'Auto-refresh or manual',
      ],
      dbTable: 'bookings',
      color: 'teal',
    },
    {
      icon: History,
      title: 'View Booking History',
      description: 'Past and current bookings',
      details: [
        'All customer bookings',
        'Service name and date',
        'Status and provider info',
        'Sort by date (newest first)',
      ],
      workflow: [
        'Navigate to history page',
        'Python queries bookings',
        'Filters by customer_id',
        'Returns full history',
        'Display in table/cards',
      ],
      dbTable: 'bookings',
      color: 'orange',
    },
    {
      icon: CreditCard,
      title: 'Payment (Simulated)',
      description: 'Mock payment process',
      details: [
        'Display service cost',
        'Enter payment method',
        'Simulate payment success',
        'Update booking status',
      ],
      workflow: [
        'After service completion',
        'Show payment interface',
        'User clicks "Pay Now"',
        'Simulate 2-second processing',
        'Mark as paid in database',
        'Show receipt',
      ],
      dbTable: 'payments',
      color: 'red',
    },
  ];

  const getColorClasses = (color: string) => {
    const colors: Record<string, { bg: string; border: string; icon: string; badge: string }> = {
      blue: { bg: 'bg-blue-50', border: 'border-blue-300', icon: 'text-blue-600', badge: 'bg-blue-600' },
      green: { bg: 'bg-green-50', border: 'border-green-300', icon: 'text-green-600', badge: 'bg-green-600' },
      purple: { bg: 'bg-purple-50', border: 'border-purple-300', icon: 'text-purple-600', badge: 'bg-purple-600' },
      yellow: { bg: 'bg-yellow-50', border: 'border-yellow-300', icon: 'text-yellow-600', badge: 'bg-yellow-600' },
      indigo: { bg: 'bg-indigo-50', border: 'border-indigo-300', icon: 'text-indigo-600', badge: 'bg-indigo-600' },
      teal: { bg: 'bg-teal-50', border: 'border-teal-300', icon: 'text-teal-600', badge: 'bg-teal-600' },
      orange: { bg: 'bg-orange-50', border: 'border-orange-300', icon: 'text-orange-600', badge: 'bg-orange-600' },
      red: { bg: 'bg-red-50', border: 'border-red-300', icon: 'text-red-600', badge: 'bg-red-600' },
    };
    return colors[color];
  };

  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-3xl font-bold text-gray-900">Customer App Features</h2>
        <p className="mt-2 text-gray-600">
          Complete feature breakdown with workflows and implementation details
        </p>
      </div>

      {/* Feature Overview */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg p-6 text-white">
        <h3 className="text-xl font-bold mb-3">Customer Application Overview</h3>
        <p className="text-blue-100 mb-4">
          A desktop application for customers to discover, book, and manage repair services with real-time status tracking.
        </p>
        <div className="grid grid-cols-4 gap-4">
          <div className="bg-white/10 rounded-lg p-3 backdrop-blur">
            <p className="text-2xl font-bold">8</p>
            <p className="text-sm text-blue-100">Core Features</p>
          </div>
          <div className="bg-white/10 rounded-lg p-3 backdrop-blur">
            <p className="text-2xl font-bold">4</p>
            <p className="text-sm text-blue-100">DB Tables</p>
          </div>
          <div className="bg-white/10 rounded-lg p-3 backdrop-blur">
            <p className="text-2xl font-bold">10+</p>
            <p className="text-sm text-blue-100">Python Scripts</p>
          </div>
          <div className="bg-white/10 rounded-lg p-3 backdrop-blur">
            <p className="text-2xl font-bold">15+</p>
            <p className="text-sm text-blue-100">UI Screens</p>
          </div>
        </div>
      </div>

      {/* Detailed Features */}
      <div className="space-y-6">
        {features.map((feature, index) => {
          const Icon = feature.icon;
          const colors = getColorClasses(feature.color);
          
          return (
            <div key={index} className={`bg-white rounded-lg border-2 ${colors.border} overflow-hidden`}>
              <div className="flex items-center gap-4 p-4 bg-gray-50 border-b border-gray-200">
                <div className={`w-12 h-12 ${colors.bg} rounded-lg flex items-center justify-center flex-shrink-0`}>
                  <Icon className={`w-6 h-6 ${colors.icon}`} />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-gray-900">{feature.title}</h3>
                  <p className="text-sm text-gray-600">{feature.description}</p>
                </div>
                <div className={`${colors.badge} text-white px-3 py-1 rounded-full text-xs font-medium`}>
                  Feature #{index + 1}
                </div>
              </div>

              <div className="p-6">
                <div className="grid grid-cols-3 gap-6">
                  {/* Feature Details */}
                  <div>
                    <h4 className="font-bold text-gray-900 mb-3 text-sm">Key Details</h4>
                    <ul className="space-y-2">
                      {feature.details.map((detail, i) => (
                        <li key={i} className="text-sm text-gray-700 flex items-start gap-2">
                          <span className={`${colors.icon} font-bold`}>•</span>
                          <span>{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Workflow */}
                  <div className="col-span-2">
                    <h4 className="font-bold text-gray-900 mb-3 text-sm">Implementation Workflow</h4>
                    <div className="space-y-2">
                      {feature.workflow.map((step, i) => (
                        <div key={i} className="flex items-start gap-3">
                          <div className={`${colors.bg} border ${colors.border} rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 font-bold text-xs ${colors.icon}`}>
                            {i + 1}
                          </div>
                          <p className="text-sm text-gray-700 pt-0.5">{step}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Database Table Reference */}
                <div className={`mt-4 ${colors.bg} border ${colors.border} rounded-lg p-3`}>
                  <p className="text-sm">
                    <span className="font-bold text-gray-900">Database Table: </span>
                    <code className={`${colors.icon} font-mono`}>{feature.dbTable}</code>
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* User Flow Diagram */}
      <div className="bg-white rounded-lg border-2 border-gray-300 p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Complete User Journey</h3>
        
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">1</div>
            <div className="flex-1 bg-blue-50 border border-blue-300 rounded-lg px-4 py-2">
              <p className="text-sm font-medium text-gray-900">Registration / Login</p>
            </div>
          </div>
          
          <div className="ml-4 border-l-2 border-gray-300 h-4"></div>
          
          <div className="flex items-center gap-3">
            <div className="bg-purple-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">2</div>
            <div className="flex-1 bg-purple-50 border border-purple-300 rounded-lg px-4 py-2">
              <p className="text-sm font-medium text-gray-900">Browse Available Services</p>
            </div>
          </div>
          
          <div className="ml-4 border-l-2 border-gray-300 h-4"></div>
          
          <div className="flex items-center gap-3">
            <div className="bg-yellow-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">3</div>
            <div className="flex-1 bg-yellow-50 border border-yellow-300 rounded-lg px-4 py-2">
              <p className="text-sm font-medium text-gray-900">Select Service & Choose Date/Time</p>
            </div>
          </div>
          
          <div className="ml-4 border-l-2 border-gray-300 h-4"></div>
          
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">4</div>
            <div className="flex-1 bg-indigo-50 border border-indigo-300 rounded-lg px-4 py-2">
              <p className="text-sm font-medium text-gray-900">Submit Service Request</p>
            </div>
          </div>
          
          <div className="ml-4 border-l-2 border-gray-300 h-4"></div>
          
          <div className="flex items-center gap-3">
            <div className="bg-teal-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">5</div>
            <div className="flex-1 bg-teal-50 border border-teal-300 rounded-lg px-4 py-2">
              <p className="text-sm font-medium text-gray-900">Track Status (Requested → Accepted → In Progress → Completed)</p>
            </div>
          </div>
          
          <div className="ml-4 border-l-2 border-gray-300 h-4"></div>
          
          <div className="flex items-center gap-3">
            <div className="bg-red-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">6</div>
            <div className="flex-1 bg-red-50 border border-red-300 rounded-lg px-4 py-2">
              <p className="text-sm font-medium text-gray-900">Make Payment (Simulated)</p>
            </div>
          </div>
          
          <div className="ml-4 border-l-2 border-gray-300 h-4"></div>
          
          <div className="flex items-center gap-3">
            <div className="bg-orange-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm">7</div>
            <div className="flex-1 bg-orange-50 border border-orange-300 rounded-lg px-4 py-2">
              <p className="text-sm font-medium text-gray-900">View Booking History</p>
            </div>
          </div>
        </div>
      </div>

      {/* UI Screens */}
      <div className="bg-white rounded-lg border-2 border-gray-300 p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">UI Screens Required</h3>
        
        <div className="grid grid-cols-3 gap-4">
          {[
            { name: 'Login Screen', components: ['Email input', 'Password input', 'Login button', 'Register link'] },
            { name: 'Registration Screen', components: ['Name, email, phone fields', 'Password & confirm', 'Submit button'] },
            { name: 'Dashboard', components: ['Welcome message', 'Service grid', 'Quick actions', 'Recent bookings'] },
            { name: 'Service Listing', components: ['Service cards', 'Search bar', 'Filter options', 'Category tabs'] },
            { name: 'Service Details', components: ['Service info', 'Price display', 'Date picker', 'Book button'] },
            { name: 'Booking Confirmation', components: ['Summary', 'Details review', 'Confirm button'] },
            { name: 'My Bookings', components: ['Booking cards', 'Status badges', 'Filter by status', 'Refresh'] },
            { name: 'Booking Details', components: ['Full info', 'Status timeline', 'Provider details', 'Actions'] },
            { name: 'Payment Screen', components: ['Amount display', 'Payment method', 'Process button', 'Receipt'] },
          ].map((screen, index) => (
            <div key={index} className="bg-gray-50 border border-gray-300 rounded-lg p-4">
              <h4 className="font-bold text-gray-900 mb-2 text-sm">{screen.name}</h4>
              <ul className="space-y-1">
                {screen.components.map((component, i) => (
                  <li key={i} className="text-xs text-gray-600 flex items-center gap-1">
                    <span className="text-gray-400">▸</span>
                    {component}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
