-- Seed Data for Service Fixing Platform
-- This provides realistic test data for demonstration

-- Insert Sample Users (Customers)
-- Password for all users: "password123" (hashed using bcrypt)
-- Hash: $2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYqJz8xVLpi

INSERT INTO users (full_name, email, phone, password_hash, user_type, address, city, state) VALUES
-- Customers
('John Smith', 'john.smith@email.com', '555-0101', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYqJz8xVLpi', 'customer', '123 Main Street, Apt 4B', 'New York', 'NY'),
('Emma Johnson', 'emma.j@email.com', '555-0102', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYqJz8xVLpi', 'customer', '456 Oak Avenue', 'Los Angeles', 'CA'),
('Michael Brown', 'mbrown@email.com', '555-0103', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYqJz8xVLpi', 'customer', '789 Pine Road', 'Chicago', 'IL'),
('Sarah Davis', 'sarah.davis@email.com', '555-0104', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYqJz8xVLpi', 'customer', '321 Elm Street', 'Houston', 'TX'),
('David Wilson', 'dwilson@email.com', '555-0105', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYqJz8xVLpi', 'customer', '654 Maple Drive', 'Phoenix', 'AZ'),

-- Service Providers
('Robert Martinez', 'robert.electrician@provider.com', '555-0201', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYqJz8xVLpi', 'provider', '111 Service Lane', 'New York', 'NY'),
('Lisa Anderson', 'lisa.plumber@provider.com', '555-0202', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYqJz8xVLpi', 'provider', '222 Work Street', 'Los Angeles', 'CA'),
('James Taylor', 'james.ac@provider.com', '555-0203', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYqJz8xVLpi', 'provider', '333 Repair Road', 'Chicago', 'IL'),
('Jennifer White', 'jennifer.laptop@provider.com', '555-0204', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYqJz8xVLpi', 'provider', '444 Tech Avenue', 'Houston', 'TX'),
('William Garcia', 'william.carpenter@provider.com', '555-0205', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewY5GyYqJz8xVLpi', 'provider', '555 Build Street', 'Phoenix', 'AZ');

-- Insert Sample Services
INSERT INTO services (service_name, category, description, base_price, duration_minutes, icon) VALUES
('Electrical Repair', 'Electrician', 'Professional electrical repair and installation services including wiring, outlets, switches, and circuit breakers.', 75.00, 90, 'zap'),
('Emergency Electrical Service', 'Electrician', '24/7 emergency electrical services for urgent issues like power outages and electrical hazards.', 150.00, 120, 'alert-circle'),
('Plumbing Repair', 'Plumber', 'Fix leaks, unclog drains, repair faucets, and general plumbing maintenance.', 80.00, 90, 'droplet'),
('Drain Cleaning', 'Plumber', 'Professional drain cleaning and unclogging services for kitchen and bathroom drains.', 65.00, 60, 'filter'),
('AC Repair & Maintenance', 'AC Repair', 'Air conditioning repair, maintenance, and servicing including cleaning and gas refilling.', 90.00, 120, 'wind'),
('AC Installation', 'AC Repair', 'Professional air conditioner installation and setup service.', 200.00, 180, 'thermometer'),
('Laptop Hardware Repair', 'Laptop Repair', 'Laptop hardware issues including screen replacement, keyboard repair, and component upgrades.', 60.00, 90, 'laptop'),
('Laptop Software Troubleshooting', 'Laptop Repair', 'Operating system installation, virus removal, and software troubleshooting.', 45.00, 60, 'hard-drive'),
('Carpentry Work', 'Carpenter', 'Furniture repair, custom woodwork, door and window installation.', 70.00, 120, 'hammer'),
('Furniture Assembly', 'Carpenter', 'Professional furniture assembly and installation service.', 50.00, 90, 'package'),
('Painting Service', 'Painter', 'Interior and exterior painting services for homes and offices.', 100.00, 240, 'paintbrush'),
('Appliance Repair', 'Appliance', 'Repair washing machines, refrigerators, microwaves, and other home appliances.', 85.00, 90, 'settings'),
('TV Mounting & Setup', 'Electronics', 'Professional TV wall mounting and setup service.', 55.00, 60, 'tv'),
('Home Cleaning', 'Cleaning', 'Deep cleaning service for homes including kitchen, bathroom, and living areas.', 95.00, 180, 'sparkles'),
('Pest Control', 'Pest Control', 'Professional pest control and fumigation services.', 120.00, 120, 'bug');

-- Insert Sample Bookings (Various Statuses)
INSERT INTO bookings (customer_id, provider_id, service_id, preferred_date, preferred_time, status, address, city, additional_notes, total_amount, payment_status, created_at) VALUES
-- Completed bookings
(1, 6, 1, '2026-01-15', '10:00:00', 'completed', '123 Main Street, Apt 4B', 'New York', 'Kitchen outlet not working', 75.00, 'paid', '2026-01-10 09:30:00'),
(2, 7, 3, '2026-01-18', '14:00:00', 'completed', '456 Oak Avenue', 'Los Angeles', 'Bathroom sink leaking', 80.00, 'paid', '2026-01-15 11:20:00'),
(3, 8, 5, '2026-01-20', '11:00:00', 'completed', '789 Pine Road', 'Chicago', 'AC not cooling properly', 90.00, 'paid', '2026-01-17 15:45:00'),

-- In Progress bookings
(4, 9, 7, '2026-02-05', '15:00:00', 'in_progress', '321 Elm Street', 'Houston', 'Laptop screen cracked', 60.00, 'pending', '2026-02-03 10:15:00'),
(5, 10, 9, '2026-02-05', '13:00:00', 'in_progress', '654 Maple Drive', 'Phoenix', 'Need custom bookshelf', 70.00, 'pending', '2026-02-02 14:30:00'),

-- Accepted bookings (scheduled for future)
(1, 6, 2, '2026-02-08', '09:00:00', 'accepted', '123 Main Street, Apt 4B', 'New York', 'Power outage in bedroom', 150.00, 'pending', '2026-02-04 16:20:00'),
(2, 7, 4, '2026-02-09', '10:30:00', 'accepted', '456 Oak Avenue', 'Los Angeles', 'Kitchen drain clogged', 65.00, 'pending', '2026-02-05 08:45:00'),
(3, 8, 6, '2026-02-10', '14:00:00', 'accepted', '789 Pine Road', 'Chicago', 'Install new AC unit in living room', 200.00, 'pending', '2026-02-05 09:30:00'),

-- Requested bookings (waiting for provider to accept)
(4, NULL, 8, '2026-02-12', '11:00:00', 'requested', '321 Elm Street', 'Houston', 'Laptop running very slow, need software cleanup', 45.00, 'pending', '2026-02-05 10:00:00'),
(5, NULL, 11, '2026-02-13', '09:00:00', 'requested', '654 Maple Drive', 'Phoenix', 'Need to paint bedroom walls', 100.00, 'pending', '2026-02-05 11:15:00'),
(1, NULL, 12, '2026-02-14', '15:00:00', 'requested', '123 Main Street, Apt 4B', 'New York', 'Washing machine not draining water', 85.00, 'pending', '2026-02-05 12:00:00'),
(2, NULL, 13, '2026-02-15', '10:00:00', 'requested', '456 Oak Avenue', 'Los Angeles', 'Mount 55 inch TV on living room wall', 55.00, 'pending', '2026-02-05 13:30:00'),

-- Cancelled booking
(3, NULL, 14, '2026-01-25', '10:00:00', 'cancelled', '789 Pine Road', 'Chicago', 'Deep cleaning needed', 95.00, 'pending', '2026-01-22 09:00:00');

-- Insert Booking Status History
INSERT INTO booking_status_history (booking_id, old_status, new_status, changed_by, remarks) VALUES
-- Booking 1 history
(1, NULL, 'requested', 1, 'Booking created'),
(1, 'requested', 'accepted', 6, 'Provider accepted the job'),
(1, 'accepted', 'in_progress', 6, 'Started working on the job'),
(1, 'in_progress', 'completed', 6, 'Job completed successfully'),

-- Booking 2 history
(2, NULL, 'requested', 2, 'Booking created'),
(2, 'requested', 'accepted', 7, 'Provider accepted the job'),
(2, 'accepted', 'in_progress', 7, 'Started repair work'),
(2, 'in_progress', 'completed', 7, 'Leak fixed successfully'),

-- Booking 3 history
(3, NULL, 'requested', 3, 'Booking created'),
(3, 'requested', 'accepted', 8, 'Provider accepted the job'),
(3, 'accepted', 'in_progress', 8, 'AC servicing started'),
(3, 'in_progress', 'completed', 8, 'AC repaired and tested'),

-- Booking 4 history
(4, NULL, 'requested', 4, 'Booking created'),
(4, 'requested', 'accepted', 9, 'Provider accepted the job'),
(4, 'accepted', 'in_progress', 9, 'Screen replacement in progress'),

-- Booking 5 history
(5, NULL, 'requested', 5, 'Booking created'),
(5, 'requested', 'accepted', 10, 'Provider accepted the job'),
(5, 'accepted', 'in_progress', 10, 'Building bookshelf'),

-- Booking 6 history
(6, NULL, 'requested', 1, 'Booking created'),
(6, 'requested', 'accepted', 6, 'Scheduled for Feb 8'),

-- Booking 7 history
(7, NULL, 'requested', 2, 'Booking created'),
(7, 'requested', 'accepted', 7, 'Scheduled for Feb 9'),

-- Booking 8 history
(8, NULL, 'requested', 3, 'Booking created'),
(8, 'requested', 'accepted', 8, 'Scheduled for Feb 10'),

-- Booking 9 history
(9, NULL, 'requested', 4, 'Booking created'),

-- Booking 10 history
(10, NULL, 'requested', 5, 'Booking created'),

-- Booking 11 history
(11, NULL, 'requested', 1, 'Booking created'),

-- Booking 12 history
(12, NULL, 'requested', 2, 'Booking created'),

-- Booking 13 history
(13, NULL, 'requested', 3, 'Booking created'),
(13, 'requested', 'cancelled', 3, 'Customer cancelled - found another service');

-- Insert Provider Earnings (for completed bookings)
INSERT INTO provider_earnings (provider_id, booking_id, amount, platform_fee, net_amount) VALUES
(6, 1, 75.00, 7.50, 67.50),  -- 10% platform fee
(7, 2, 80.00, 8.00, 72.00),
(8, 3, 90.00, 9.00, 81.00);

-- Display summary
SELECT 'Seed data inserted successfully!' AS message;
SELECT 'Database Summary:' AS info;
SELECT COUNT(*) AS total_users FROM users;
SELECT COUNT(*) AS total_customers FROM users WHERE user_type = 'customer';
SELECT COUNT(*) AS total_providers FROM users WHERE user_type = 'provider';
SELECT COUNT(*) AS total_services FROM services;
SELECT COUNT(*) AS total_bookings FROM bookings;
SELECT status, COUNT(*) AS count FROM bookings GROUP BY status;
