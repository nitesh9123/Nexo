-- Service Fixing Platform Database Schema
-- MySQL 8.0+

-- Drop existing tables if they exist (for clean setup)
DROP TABLE IF EXISTS booking_status_history;
DROP TABLE IF EXISTS provider_earnings;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS services;
DROP TABLE IF EXISTS users;

-- Table 1: Users (Both Customers and Service Providers)
CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    password_hash VARCHAR(255) NOT NULL,
    user_type ENUM('customer', 'provider') NOT NULL,
    profile_picture VARCHAR(255) DEFAULT NULL,
    address TEXT,
    city VARCHAR(50),
    state VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    
    INDEX idx_email (email),
    INDEX idx_user_type (user_type),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table 2: Services
CREATE TABLE services (
    service_id INT PRIMARY KEY AUTO_INCREMENT,
    service_name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    description TEXT,
    base_price DECIMAL(10, 2) NOT NULL,
    duration_minutes INT DEFAULT 60,
    icon VARCHAR(100) DEFAULT 'wrench',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_category (category),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table 3: Bookings
CREATE TABLE bookings (
    booking_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL,
    provider_id INT NULL,
    service_id INT NOT NULL,
    
    preferred_date DATE NOT NULL,
    preferred_time TIME NOT NULL,
    
    status ENUM('requested', 'accepted', 'in_progress', 'completed', 'cancelled') 
        DEFAULT 'requested',
    
    address TEXT NOT NULL,
    city VARCHAR(50),
    additional_notes TEXT,
    
    total_amount DECIMAL(10, 2) NOT NULL,
    payment_status ENUM('pending', 'paid') DEFAULT 'pending',
    payment_method VARCHAR(50) DEFAULT 'cash',
    
    customer_rating INT DEFAULT NULL,
    customer_review TEXT DEFAULT NULL,
    
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    
    FOREIGN KEY (customer_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (provider_id) REFERENCES users(user_id) ON DELETE SET NULL,
    FOREIGN KEY (service_id) REFERENCES services(service_id) ON DELETE RESTRICT,
    
    INDEX idx_customer (customer_id),
    INDEX idx_provider (provider_id),
    INDEX idx_status (status),
    INDEX idx_date (preferred_date),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table 4: Booking Status History (Audit Trail)
CREATE TABLE booking_status_history (
    history_id INT PRIMARY KEY AUTO_INCREMENT,
    booking_id INT NOT NULL,
    old_status VARCHAR(50),
    new_status VARCHAR(50) NOT NULL,
    changed_by INT,
    remarks TEXT,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    FOREIGN KEY (changed_by) REFERENCES users(user_id) ON DELETE SET NULL,
    
    INDEX idx_booking (booking_id),
    INDEX idx_date (changed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Table 5: Provider Earnings
CREATE TABLE provider_earnings (
    earning_id INT PRIMARY KEY AUTO_INCREMENT,
    provider_id INT NOT NULL,
    booking_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    platform_fee DECIMAL(10, 2) DEFAULT 0.00,
    net_amount DECIMAL(10, 2) NOT NULL,
    earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (provider_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE CASCADE,
    
    INDEX idx_provider (provider_id),
    INDEX idx_date (earned_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create a view for booking details (makes queries easier)
CREATE VIEW booking_details AS
SELECT 
    b.booking_id,
    b.customer_id,
    c.full_name AS customer_name,
    c.email AS customer_email,
    c.phone AS customer_phone,
    b.provider_id,
    p.full_name AS provider_name,
    p.phone AS provider_phone,
    b.service_id,
    s.service_name,
    s.category,
    s.base_price,
    b.preferred_date,
    b.preferred_time,
    b.status,
    b.address,
    b.city,
    b.additional_notes,
    b.total_amount,
    b.payment_status,
    b.payment_method,
    b.customer_rating,
    b.customer_review,
    b.created_at,
    b.updated_at,
    b.completed_at
FROM bookings b
INNER JOIN users c ON b.customer_id = c.user_id
LEFT JOIN users p ON b.provider_id = p.user_id
INNER JOIN services s ON b.service_id = s.service_id;

-- Success message
SELECT 'Database schema created successfully!' AS message;
